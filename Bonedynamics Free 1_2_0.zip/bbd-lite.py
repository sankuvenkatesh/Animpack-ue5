bl_info = \
    {
        "name" : "Bonedynamics Free",
        "author" : "Morelewd",
        "version" : (1, 2, 0),
        "blender" : (2, 91, 0),
        "location" : "UI > BD Free",
        "description" :
            "Apply physics to bones",
        "warning" : "", 
        "wiki_url" : "",
        "tracker_url" : "",
        "category" : "Animation",
    }


 


import bpy
from bpy.props import PointerProperty
import mathutils
from mathutils import Matrix
import bmesh

# FIND COLLECTION OR CREATE ONE
list1 = []

presets = [
# mass , friction , damping , goal_min , stiffness , speed, bend , spring
[0.3 , 12, 20 ,0.69 , 0.5 ,1.0, 0.0 , 0.5], #default
[1,  1  ,6  , 0.5 , .1   ,1 , 0.0, 0.999], #hair
[0.59 , 25.4, 0.0 ,0.81 , 0.21 ,1.0, 0.0, 0.6], #organic
[0.59 , 30.4, 50.0 ,0.77 , 0.41 ,1.0, 0.0, 0.999], #Slow
[0.17 , 3.3, 8.75 ,0.77 , 0.99 ,1.0, 0.0, 0.999], #Stiff
[2 , 15, 50 , 0.80 , 0.99 ,1.0, 0.0, 0.99] #heavy
]


presetsChain = [

# mass , friction , damping , goal_min , stiffness , speed, bend , spring
[1.2, 0.6 , 3.2 ,0.2 , 0.0 ,1.0, 0.1, 0.999], #default
[0.5,  .1  , 2  , 0.0 , 0.99   ,1.5, 0.0, 0.5], #hair
[0.89 , 12.4, 8.0 ,0.21 , 0.21 ,1.0, 10.0, 0.999], #organic
[0.59 , 30.4, 50.0 ,0.77 , 0.41 ,1.0, 10.0, 0.999], #Slow
[0.17 , 3.3, 8.75 ,0.77 , 0.99 ,1.0, 10.0, 0.999], #Stiff
[1.3 , 0.35, 5 ,0.0 , 0.01 ,1.0, 0.10, 0.90] #heavy
]



def update_enum(self, context):
    idx = int(self.my_enum)
    list= []
    if context.scene.chainMode:
        list = presetsChain
    else:
        list = presets
    context.scene.boneMass = list[idx][0]
    context.scene.boneFriction = list[idx][1]
    context.scene.boneStiffness = list[idx][4]
    context.scene.boneDamping = list[idx][2]
    context.scene.boneStrength = list[idx][3]
    context.scene.boneSpeed = list[idx][5]
    context.scene.boneBend = list[idx][6]
    context.scene.boneSpring = list[idx][7]


def update_chain (self, context):
        update_enum(self, context)

def findCollection(context):
        if not any(collection.name == "BoneDynamics" for collection in bpy.data.collections):
            my_coll = bpy.data.collections.new("BoneDynamics")  
            bpy.context.scene.collection.children.link(my_coll)
            
def set_collection(collection_name):
    if collection_name in bpy.context.view_layer.layer_collection.children:
        root=bpy.context.view_layer.layer_collection.children[collection_name]
    else:
        coll=bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(coll)
        root=bpy.context.view_layer.layer_collection.children[coll.name]

    bpy.context.view_layer.active_layer_collection=root
    return(root)
       
def main(self , context):
    blist = []
    previouslayers = []
    active = context.object.data.bones.active
    arma = context.active_object


#    if len(bpy.context.selected_pose_bones) == 1 and context.active_pose_bone.parent == None and context.scene.dynamicParent == False :
#        self.report({'ERROR'}, 'you selected a bone that has no parent , please select another bone with a parent ')
#        return None
    if len(bpy.context.selected_pose_bones) > 0:
        for num , ob in enumerate(context.selected_pose_bones):
                  if  len(bpy.context.selected_pose_bones) > 0 and ob.parent:
                
                    obj = ob.id_data
                    armature = ob.id_data.name
                    item = [ob.name,num,ob.tail,ob.length, ob.head]
                    T =  Matrix.Translation(ob.tail - ob.head)
                    thead= Matrix.Translation(1.0 * (ob.tail - ob.head))
                    ttail=  Matrix.Translation(0 * (ob.tail - ob.head))
                    mathead = obj.matrix_world @ (thead @ ob.matrix)
                    mattail = obj.matrix_world @ (ttail @ ob.matrix)                    
                    matrix_final = obj.matrix_world @ (T @ ob.matrix)

                    item = [ob.name,num,ob.tail,ob.length,ob.head, matrix_final , ob.parent, armature, mathead , mattail, ob]

                    blist.append(item)                

        if context.scene.chainMode:
            makeChainphysics(self ,context )                
        else:
            makePhysics(self ,context , blist)
    else:
        self.report({'ERROR'}, 'Selection is empty, please select at least two bones.')




def findroot(self , context):
    
    if len(context.selected_pose_bones) == 1:
        return context.active_pose_bone.parent       
    for num , ob in enumerate(context.selected_pose_bones):
        if ob.parent in context.selected_pose_bones:
            continue
        else:
            if ob.parent:
                return ob.parent
            else:
                if len(context.selected_pose_bones) == 2 and ob.parent != context.active_pose_bone:
                    return context.active_pose_bone
                return ob


def makeChainphysics(self , context):
    arma = context.active_object
#    bpy.ops.object.mode_set(mode='OBJECT')
  
    parent = findroot(self , context)    
    for num,  ob in enumerate(context.selected_pose_bones):
        if ob.bone.use_connect == False and  ob != parent:
           self.report({'WARNING'}, "using the chain mode on disconnected bones can lead to errors.")
           break
    boneLength = 0
    verts = list()
    edges = list()
    numb = 0 
    my_dict = [];
#    recursiveList = [value for value in parent.children_recursive if value in context.selected_pose_bones]
    tails = {}
    for num,  ob in enumerate(context.selected_pose_bones):
        recursive = [value for value in ob.children_recursive if value in context.selected_pose_bones]
        tails[ob.name] = 1 - (len(recursive) / len(context.selected_pose_bones) )


    for num,  ob in enumerate(context.selected_pose_bones):
        if 'dynamics' in ob :
            continue

        T =  Matrix.Translation(ob.tail - ob.head)
        matrix_final = arma.matrix_world @ (T @ ob.matrix)
        thead= Matrix.Translation(1.0 * (ob.tail - ob.head))
        ttail=  Matrix.Translation(0 * (ob.tail - ob.head))
        mathead = arma.matrix_world @ (thead @ ob.matrix)
        mattail = arma.matrix_world @ (ttail @ ob.matrix)
        headpos = mathead.to_translation()
        tailpos = mattail.to_translation()
        verts.append(headpos)
        verts.append(tailpos)
        my_dict.append([ob.name, headpos , tailpos])
        boneLength = (ob.length / 100 )* abs(arma.scale.x)
        edges.append([num + numb , num + numb+1])
        edges.append([num + numb + 1 , num + numb])
        numb += 1 
        if parent:
            name = parent.name + '|' + parent.id_data.name
            if ob != parent:
                ob['dynamics'] = True
                ob['chain'] = True
        else: 
            name = ob.name + '|' + ob.id_data.name
        print('bonelength' , boneLength) 
        bpy.ops.ed.undo_push()
        if ob == context.selected_pose_bones[-1]:
          mesh = bpy.data.meshes.new(name) 
          mesh.from_pydata(verts, edges, []) 
          obj = bpy.data.objects.new(name, mesh) 
          bpy.data.collections['BoneDynamics'].objects.link(obj)
          for bone  in context.selected_pose_bones:
            bone.bbdObject = obj
          bpy.ops.object.mode_set(mode='OBJECT')
          bpy.ops.object.select_all(action='DESELECT')
          context.view_layer.objects.active = obj 
          obj.select_set(True)
          obj["dynamics"] = True
          obj["chain"] = True
          obj['arma'] = arma.id_data
          bpy.context.object.data.validate()
          bpy.ops.object.mode_set(mode='EDIT')
          bpy.ops.mesh.select_all(action='SELECT')
          print('bonelength' , boneLength)
          bpy.ops.mesh.remove_doubles(threshold= boneLength)
          bpy.ops.object.mode_set(mode='OBJECT')
          bm = obj.data

          for v in bm.vertices:
                for b in my_dict:
                    result = v.co - b[1]     
                    if result.length < abs(boneLength):
                        if b[0] == parent.name:
                             if not "Pin" in [g.name for g in obj.vertex_groups]:
                                pin_group = obj.vertex_groups.new(name = "Pin")
                                pin_group.add([v.index], 1.0, 'REPLACE')
                             else:
                                pin_group = obj.vertex_groups["Pin"]
                                pin_group.add([v.index], 1.0, 'REPLACE')
                            
    
                        group = obj.vertex_groups.new(name = b[0])
                        
                        tailsgroup = (obj.vertex_groups.get("tails")
                                or obj.vertex_groups.new(name = "tails"))
                        if  b[0] != parent.name:
                           tailsgroup.add([v.index], tails[b[0]], 'REPLACE')
                        obj.vertex_groups[group.index].add([v.index], 1.0, 'REPLACE')
          vgroup_names = {vgroup.index: vgroup.name for vgroup in obj.vertex_groups}
          vgroups = {v.index: [vgroup_names[g.group] for g in v.groups] for v in bm.vertices}
          for v in bm.vertices:
              if len(vgroups[v.index])  == 0:
                  if not "Pin" in [g.name for g in obj.vertex_groups]:
                    pin_group = obj.vertex_groups.new(name = "Pin")
                  else:
                    pin_group = obj.vertex_groups["Pin"]
                  obj.vertex_groups[pin_group.index].add([v.index], 1.0, 'REPLACE')
          bpy.context.object.data.validate()
             
          bpy.ops.object.mode_set(mode='OBJECT')

          bpy.context.view_layer.objects.active = arma

          if(parent.name):
                parentB = arma.pose.bones.get(parent.name)
                obj.parent= arma
                obj.parent_type = "BONE"
                obj.parent_bone = parent.name
                obj.matrix_parent_inverse = (arma.matrix_world @ Matrix.Translation(parentB.tail - parentB.head) @ parentB.matrix).inverted()
         

          bpy.ops.object.mode_set(mode='POSE') 
          bpy.context.view_layer.objects.active = arma
             
          for bone  in context.selected_pose_bones: 
            if bone == parent:
                continue
            bn = arma.pose.bones.get(bone.name)
            nme = 'BoneDynamics-damped-' + bone.name
            constraintName = 'STRETCH_TO' if context.scene.boneStretch == True else 'DAMPED_TRACK'
            cr = (bn.constraints.get(nme)
                    or bn.constraints.new(type=constraintName))
#            obj = bpy.data.objects[name]
            cr.target = obj 
            cr.subtarget = bone.name
            cr.name= nme       
          bpy.ops.object.mode_set(mode='OBJECT')
          bpy.ops.object.select_all(action='DESELECT')
          context.view_layer.objects.active = obj 
          obj.select_set(True)
          modi = obj.modifiers.new(name = "Soft Body", type='SOFT_BODY')
          mod = modi.settings       
          modi.point_cache.frame_start = context.scene.frame_start 
          modi.point_cache.frame_end = context.scene.frame_end  
          mod.vertex_group_goal = "Pin"
          mod.use_edges = True
          mod.use_face_collision = True
          mod.use_edge_collision = True
          mod.use_stiff_quads = True
          mod.pull = context.scene.boneSpring
          mod.push = context.scene.boneSpring
          mod.vertex_group_mass = "tails"

          mod.damping = 0
          mod.spring_length = 100
          mod.goal_default = 1  
        ## settings ##
          mod.bend = context.scene.boneBend
          mod.friction = context.scene.boneFriction
          mod.mass= context.scene.boneMass 
          mod.goal_spring  = context.scene.boneStiffness
          mod.goal_friction = context.scene.boneDamping
          mod.goal_min = context.scene.boneStrength
          mod.speed = context.scene.boneSpeed
          bpy.ops.object.select_all(action='DESELECT')
    context.view_layer.objects.active = arma 
    bpy.ops.object.mode_set(mode='POSE')
    
def makePhysics(self , context , blist):
    arma = context.active_object
    parent = context.active_pose_bone.name
    bpy.ops.object.mode_set(mode='OBJECT')
   
        
    for obj in blist:           
        loc= obj[5]
        lin= context.scene.cubeSize
        obname = obj[0 ] + '|' + obj[7]
        pBone = obj[10]
        cube = context.scene.objects.get(obname)
        if cube:
         continue 
        root = set_collection('BoneDynamics')
        mesh = bpy.data.meshes.new("mesh")  # add a new mesh
        boneobj = bpy.data.objects.new(obname, mesh)  # add a new object using the mesh
        bpy.ops.object.select_all(action='DESELECT')
        bpy.data.collections['BoneDynamics'].objects.link(boneobj)
        bpy.context.view_layer.objects.active = boneobj
        boneobj.select_set(True)  # select object
        pBone['dynamics'] = True
        pBone.bbdObject = boneobj
        verts = (obj[8].to_translation(), obj[9].to_translation())
        edges = ([0,1] ,[1,0])
        mesh.from_pydata(verts , edges , [])
        me = boneobj.data
        origin = me.vertices[1].co
        bpy.context.scene.cursor.location = me.vertices[1].co
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
        pingroup = boneobj.vertex_groups.new(name = "Pin")
        fallroup = boneobj.vertex_groups.new(name = "Fall")
        boneobj.vertex_groups[pingroup.index].add([1], 1.0, 'REPLACE')
        boneobj.vertex_groups[fallroup.index].add([0], 1.0, 'REPLACE')

        bpy.ops.object.mode_set(mode='OBJECT')
        
        
        bpy.ops.ed.undo_push()
        obj2 = context.active_object
        modi = obj2.modifiers.new(name = "Soft Body", type='SOFT_BODY')
        mod = modi.settings       
        modi.point_cache.frame_start = context.scene.frame_start 
        modi.point_cache.frame_end = context.scene.frame_end  
        mod.vertex_group_goal = "Pin"
        mod.vertex_group_mass = "Fall"
        mod.use_edges = True
        mod.use_face_collision = True
        mod.use_edge_collision = True

        mod.use_stiff_quads = True
        mod.pull = context.scene.boneSpring
        mod.push = context.scene.boneSpring
        
        mod.damping = 0
        mod.spring_length = 100
        mod.goal_default = 1  
        ## settings ##
        mod.bend = context.scene.boneBend
        mod.friction = context.scene.boneFriction
        mod.mass= context.scene.boneMass 
        mod.goal_spring  = context.scene.boneStiffness
        mod.goal_friction = context.scene.boneDamping
        mod.goal_min = context.scene.boneStrength
        mod.speed = context.scene.boneSpeed
        
        
        obj2.hide_render = True
        obj2.select_set(True)
        arma.select_set(True) 
        bpy.context.view_layer.objects.active = arma


        if obj[6]:
            print('parent name', obj[6])
            parentName = obj[6].name
            if(parentName):
                parentB = arma.pose.bones.get(parentName)
                obj2.parent= arma
                obj2.parent_type = "BONE"
                obj2.parent_bone = parentName
                obj2.matrix_parent_inverse = (arma.matrix_world @ Matrix.Translation(parentB.tail - parentB.head) @ parentB.matrix).inverted()
                
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        obj2.display_type = 'WIRE'
        obj2.hide_render = True

    bpy.ops.object.mode_set(mode='POSE')
    constraintName = 'STRETCH_TO' if context.scene.boneStretch == True else 'DAMPED_TRACK'
    for bne in blist: 
        bn = arma.pose.bones.get(bne[0])
        nme = 'BoneDynamics-damped-' + bne[10].name
        crobname = bne[10].name + '|' + bne[10].id_data.name
        cr = (bn.constraints.get(nme)
                or bn.constraints.new(type=constraintName))
        obj = bpy.data.objects[crobname]
        cr.target = obj 
        cr.subtarget = 'Fall'
        cr.name= 'BoneDynamics-damped-' + bne[0]
        # cr.bulge = 0
        context_py = bpy.context.copy()
        context_py["constraint"] = cr    
    blist.clear()
    zbone = arma.data.bones[parent]
    arma.data.bones.active = zbone



def clearScene(self,context):
    bonenames = []
    for bone in bpy.context.selected_pose_bones:
        for c in bone.constraints:
            
             if c.name == 'BoneDynamics-damped-' + bone.name or c.name == "BoneDynamics-displace-" + bone.name :
                if c.name == "BoneDynamics-displace-" + bone.name:
                    if not bone.id_data.override_library: 
                        toggleConnect(self , context, bone , True)
                bone.constraints.remove( c )
                obname = bone.name + '|' + bone.id_data.name
                bonenames.append(obname)
                    
        try:
                bpy.data.objects.remove(bone['bbdObject'], do_unlink = True)
        except:
                print('object not found')
        try:
            for c in bpy.data.collections['BoneDynamics'].objects:
                if c.name in bonenames:
                    bpy.data.objects.remove(bpy.context.scene.objects[c.name], do_unlink = True)
        except:
                print('object not found')
        try:
            del bone['chain']
        except:
            print('property not found')
        try:
            del bone['displace']
        except:
            print('property not found')
        try:
                del bone['dynamics']
                del bone['bbd-parent']
        except:
                print('property not found')
                
    if len(bpy.data.collections['BoneDynamics'].objects) < 1:
        coll = bpy.data.collections.get('BoneDynamics')
        bpy.data.collections.remove(coll)
    bonenames.clear() 
    



class BoneDynamics(bpy.types.Operator):
    """Make sure you are in Pose mode, select the bone and hit this button if you select more than one bone, the active bone will be the parent"""
    bl_idname = "object.add_bonedynamics"
    bl_label = "Simple Object Operator"

    @classmethod
    def poll(cls, context):
       if context.mode == 'POSE' and len(context.selected_pose_bones) > 0:                  
            return True
       else:
            return False
       return context.active_object.type == "ARMATURE"

    def execute(self, context):
   
        findCollection(context)
        main(self, context)

        return {'FINISHED'}
    
class RemoveBoneDynamics(bpy.types.Operator):
    """This cleans up the bone and will bring it back to its original state"""
    bl_idname = "object.remove_bonedynamics"
    bl_label = "Simple Object Operator"

    @classmethod
    def poll(cls, context):
        if not any(collection.name == "BoneDynamics" for collection in bpy.data.collections):
            return False
        if context.mode == 'POSE':
            return True
        else:
            return False
        return context.active_object.type == "ARMATURE"

    def execute(self, context):
        clearScene(self,context)
        return {'FINISHED'}

class AddPoseBone(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.add_posebone"
    bl_label = "Simple Object Operator"

    @classmethod
    def poll(cls, context):
       if context.mode == 'POSE' and len(context.selected_pose_bones) > 0:                  
            return True
       else:
            return False
       return context.active_object.type == "ARMATURE"

    def execute(self, context):
        makeBonePosable(self,context)
        return {'FINISHED'}




class bonePanel(bpy.types.Panel):
    bl_label = "BoneDynamics Free"
    bl_idname = "PT_Phyton"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BD Free'
   
    def draw(self, context):
        layout = self.layout
        
        row = layout.column(align=True)

        row.label(text="Presets" , icon="OPTIONS")
        row.prop(context.scene, "my_enum")
        row.operator('object.add_bonedynamics', text ="Add Bone Dynamics" )

        row.operator('object.remove_bonedynamics', text ="Remove Bone Dynamics" )
        row.operator('wm.myop', text ="Bake Animation" )
        row.prop(context.scene, "boneStretch")
        row.prop(context.scene, "chainMode")

        

class WM_OT_bakeBone(bpy.types.Operator):
    """bake the physics of the selected bones into keyframes"""
    bl_idname = "wm.myop"
    bl_label = "Bake the animation of the selected bones"
    # annotations in 2.8
    prop1: bpy.props.BoolProperty(default = True)

    @classmethod
    def poll(cls, context):
        if context.mode == 'POSE' and len(context.selected_pose_bones) > 0 and context.active_object.type == "ARMATURE": 
            return True
        else:
            return False

    def execute(self, context):
        arma = context.active_object
        start = context.scene.frame_start 
        end = context.scene.frame_end

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        arma.select_set(True)

        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.nla.bake(frame_start = start, frame_end = end, use_current_action = True, only_selected = True, visual_keying = True, bake_types={'POSE'})
        if self.prop1:
            clearScene(self , context)

        
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    def draw(self, context):
        row = self.layout
        row.label(text='IMPORTANT:',  translate=True, icon='NONE', icon_value=0)
        row.label(text='the baking range will follow the timeline length.',  translate=True, icon='NONE', icon_value=0)
        row.prop(self, "prop1", text="Clear constraints and physics object" )       
            

       
def register():

    bpy.utils.register_class(bonePanel)
    bpy.utils.register_class(BoneDynamics)
    bpy.utils.register_class(WM_OT_bakeBone)

    bpy.types.Scene.boneStretch = bpy.props.BoolProperty(
        name="Allow bone stretching",
        description="Allow bones to change size",
        default = False)
    bpy.types.Scene.chainMode = bpy.props.BoolProperty(
        name="Chain mode",
        description="The chain mode is useful for a connected long chain of bones like hairs",
        default = False , update=update_enum)
    bpy.types.Scene.my_enum = bpy.props.EnumProperty(
            name = "",
            description = "Presets for physics",
            items = [
                ("0", "Default", "Default settings"),
                ("1", "Hair", "Hair settings"),
                ("2", "Organic", "Organic settings"), 
                ("3", "Slow", "Slow settings"),         
                ("4", "Stiff", "Stiff settings"),        
                ("5", "heavy", "heavy settings"),        
            ],
            update=update_enum
        )


    bpy.types.Scene.cubeSize = bpy.props.FloatProperty(name = "cube size",description="size of the cube",default = 0.2 ,min = 0 ,max = 10  )
    bpy.types.Scene.boneMass = bpy.props.FloatProperty(name = "Mass",description="",default = 0.3 ,min = 0 ,max = 10  )
    bpy.types.Scene.boneFriction = bpy.props.FloatProperty(name = "Friction",description="",default = 12 ,min = 0 ,max = 50 )
    bpy.types.Scene.boneStiffness = bpy.props.FloatProperty(name = "Stiffness",description="",default = 0.9 ,min = 0 ,max = 1 )
    bpy.types.Scene.boneDamping = bpy.props.FloatProperty(name = "Damping",description="",default = 10 ,min = 0 ,max = 50 )
    bpy.types.Scene.boneStrength = bpy.props.FloatProperty(name = "Strength",description="",default = 0.7 ,min = 0 ,max = 1 )
    bpy.types.Scene.boneSpeed = bpy.props.FloatProperty(name = "Speed",description="",default = 1 ,min = 0 ,max = 100 )
    bpy.types.PoseBone.bbdObject = bpy.props.PointerProperty(name = "bbd pointer" , type=bpy.types.Object ,  options = {'LIBRARY_EDITABLE' }, override = {'LIBRARY_OVERRIDABLE'}  )
    bpy.types.Scene.boneBend = bpy.props.FloatProperty(name = "Bend",description="",default = 1 ,min = 0 ,max = 10 )
    bpy.types.Scene.boneSpring = bpy.props.FloatProperty(name = "Spring",description="",default = 0.5 ,min = 0 ,max = 1 )
    bpy.utils.register_class(RemoveBoneDynamics)
   
def unregister():
    bpy.utils.unregister_class(bonePanel)
    bpy.utils.unregister_class(BoneDynamics)
    bpy.utils.unregister_class(WM_OT_bakeBone)

    bpy.utils.unregister_class(RemoveBoneDynamics)

    del bpy.types.Scene.boneStretch
    del bpy.types.Scene.cubeSize
    del bpy.types.Scene.my_enum
    del bpy.types.Scene.boneMass
    del bpy.types.Scene.boneFriction
    del bpy.types.Scene.boneStiffness
    del bpy.types.Scene.boneDamping
    del bpy.types.Scene.boneStrength
    del bpy.types.Scene.boneSpeed
    del bpy.types.Scene.boneBend
    del bpy.types.Scene.boneSpring
   
if __name__ == "__main__":
    register() 