bl_info = \
    {
        "name" : "BoneDynamics Pro",
        "author" : "Morelewd",
        "version" : (2, 0, 1),
        "blender" : (2, 91, 0),
        "location" : "UI > BD Pro",
        "description" :
            "Bones with physics",
        "warning" : "", 
        "wiki_url" : "",
        "tracker_url" : "",
        "category" : "Animation",
    }


import bpy
from bpy.props import PointerProperty
import mathutils
from mathutils import Matrix, Vector,  Euler
from math import pi
import math
import bmesh
import threading
from bl_operators.presets import AddPresetBase
from bpy.types import Panel, Menu
import shutil
import os
from os.path import basename, splitext
import blf
import gpu
import time
import numpy as np
from bpy_extras import anim_utils



# ------------------------------------------------------------------------
# CONFIGURATION DATA
# ------------------------------------------------------------------------

TIPS_DATA = [
    "Shift + R: Rotate dynamic bones | Shift + T: Translate (Displacement ON).",
    "Displacement = movement instead of rotation (must be set beforehand)",
    "Chain mode are designed for linked bones only (must be set beforehand).",
    "Chain endpoints can be controlled with a Hook Modifier on the simulated mesh.",
    "Dynamic Parent allows the active bone to become the parent of the selection (must be set beforehand).",
    "Transfer Animation copies animation keyframes to the simulated mesh .",
    "To make a seamless loop, you must duplicate your timeline 2 times and pick the last loop",
    "If you change the timeline range while having dynamic bones, you must select them and use the Sync time Range"
]

# ------------------------------------------------------------------------
# UTILITIES
# ------------------------------------------------------------------------

def smoothstep(edge0, edge1, x):
    """Interpolation helper for smooth easing."""
    x = max(0.0, min(1.0, (x - edge0) / (edge1 - edge0)))
    return x * x * (3 - 2 * x)

# ------------------------------------------------------------------------
# DRAWING HANDLER
# ------------------------------------------------------------------------

def draw_callback_px(self, context):
    if not context.window_manager.show_helper_tips:
        return

    font_id = 0
    wm = context.window_manager
    
    # Settings
    duration = wm.helper_tips_duration
    fade_time = wm.helper_tips_fade
    
    # Sanity check: Fade time can't be longer than half the duration
    if fade_time * 2 > duration:
        fade_time = duration / 2

    # Time calculations
    current_time = time.time()
    total_elapsed = current_time - self.start_time
    
    # Which tip index are we on?
    tip_index = int(total_elapsed // duration) % len(self.tips)
    text = self.tips[tip_index]
    
    # Calculate time within the current specific tip cycle (0.0 to duration)
    cycle_time = total_elapsed % duration
    
    # Calculate Alpha (Opacity) with Easing
    alpha = 1.0
    
    if cycle_time < fade_time:
        # Fading In
        alpha = smoothstep(0, fade_time, cycle_time)
    elif cycle_time > (duration - fade_time):
        # Fading Out
        time_left = duration - cycle_time
        alpha = smoothstep(0, fade_time, time_left)
    else:
        # Fully Visible
        alpha = 1.0

    # 3. Text Styling
    font_size = 14
    # White text with calculated alpha
    text_color = (1.0, 1.0, 1.0, alpha) 
    # Black shadow with calculated alpha (max 0.8)
    shadow_color = (0.0, 0.0, 0.0, alpha * 0.8) 
    
    blf.size(font_id, font_size)
    
    # 4. Position (Bottom Left)
    padding_x = 60 # Distance from left edge
    padding_y = 60 # Distance from bottom edge
    
    x_pos = padding_x
    y_pos = padding_y

    # 5. Draw Shadow
    if alpha > 0.01: # Optimization: Don't draw if invisible
        blf.position(font_id, x_pos + 2, y_pos - 2, 0)
        blf.color(font_id, *shadow_color)
        blf.draw(font_id, text)

        # 6. Draw Main Text
        blf.position(font_id, x_pos, y_pos, 0)
        blf.color(font_id, *text_color)
        blf.draw(font_id, text)

# ------------------------------------------------------------------------
# MODAL OPERATOR
# ------------------------------------------------------------------------



BDP_COPIED_PROPERTIES = {}

class BDP_OT_CopyProperties(bpy.types.Operator):
    """Copy dynamic properties from the active bone"""
    bl_idname = "pose.bdp_copy_properties"
    bl_label = "Copy Values"

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and context.active_pose_bone

    def execute(self, context):
        global BDP_COPIED_PROPERTIES
        bone = context.active_pose_bone
        props = [
            'boneMass', 'boneBend', 'boneSpeed', 'boneDamping', 
            'boneStiffness', 'boneElasticity', 'boneFriction', 
            'collisionDistance', 'boneGravity'
        ]
        
        for p in props:
            BDP_COPIED_PROPERTIES[p] = getattr(bone, p, None)
            
        self.report({'INFO'}, f"Copied dynamics from {bone.name}")
        return {'FINISHED'}


class BDP_OT_PasteProperties(bpy.types.Operator):
    """Paste copied dynamic properties to all selected bones"""
    bl_idname = "pose.bdp_paste_properties"
    bl_label = "Paste Values"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        global BDP_COPIED_PROPERTIES
        return context.mode == 'POSE' and len(context.selected_pose_bones) > 0 and bool(BDP_COPIED_PROPERTIES)

    def execute(self, context):
        global BDP_COPIED_PROPERTIES
        props = [
            'boneMass', 'boneBend', 'boneSpeed', 'boneDamping', 
            'boneStiffness', 'boneElasticity', 'boneFriction', 
            'collisionDistance', 'boneGravity'
        ]
        
        for bone in context.selected_pose_bones:
            for p in props:
                val = BDP_COPIED_PROPERTIES.get(p)
                if val is not None:
                    setattr(bone, p, val)
                    
        self.report({'INFO'}, f"Pasted dynamics to {len(context.selected_pose_bones)} bone(s)")
        return {'FINISHED'}


class VIEW3D_OT_helper_tips(bpy.types.Operator):
    bl_idname = "view3d.helper_tips_overlay"
    bl_label = "Helper Tips Overlay"
    bl_description = "Displays rotating helper tips in the viewport"

    _handle = None
    _timer = None

    def modal(self, context, event):
        if event.type == 'ESC':
            self.cancel(context)
            context.window_manager.show_helper_tips = False
            return {'CANCELLED'}

        if not context.window_manager.show_helper_tips:
            self.cancel(context)
            return {'FINISHED'}

        if event.type == 'TIMER':
            if context.area:
                context.area.tag_redraw()

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            self.tips = TIPS_DATA
            self.start_time = time.time()

            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(
                draw_callback_px, args, 'WINDOW', 'POST_PIXEL'
            )
            
            # High frequency timer for smooth fade animation
            self._timer = context.window_manager.event_timer_add(0.03, window=context.window)
            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found")
            return {'CANCELLED'}

    def cancel(self, context):
        if self._handle:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self._handle = None
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)

# ------------------------------------------------------------------------
# UI PANEL & PROPERTY UPDATER
# ------------------------------------------------------------------------

def update_tips_toggle(self, context):
    if self.show_helper_tips:
        bpy.ops.view3d.helper_tips_overlay('INVOKE_DEFAULT')


def get_selected_chain_roots():
    """
    Finds the root bone for every disconnected chain within the current
    bone selection in Pose Mode.

    A bone is identified as a root of a chain if it is selected but its
    parent is not selected, or if it has no parent at all.

    Returns:
        list[str]: A list of names of all root bones found. Returns an
                   empty list if no valid selection is made.
    """
    if not bpy.context.object or bpy.context.object.mode != 'POSE':
        print("Error: Please be in Pose Mode with an active armature.")
        return []

    selected_pose_bones = bpy.context.selected_pose_bones
    if not selected_pose_bones:
        return []

    selected_names = {bone.name for bone in selected_pose_bones}

    root_bones = []
    for bone in selected_pose_bones:
        if bone.parent is None:
            root_bones.append(bone)
        elif bone.parent.name not in selected_names:
            root_bones.append(bone)

    return [bone.name for bone in root_bones]


def get_world_scale(obj):
    """
    Calculate the cumulative world scale of an object including all parent scales.
    
    Args:
        obj: The Blender object to get the scale for
        
    Returns:
        Vector: The cumulative world scale
    """
    scale = obj.scale.copy()
    current_obj = obj
    
    while current_obj.parent:
        current_obj = current_obj.parent
        scale.x *= current_obj.scale.x
        scale.y *= current_obj.scale.y
        scale.z *= current_obj.scale.z
    
    return scale


def get_bone_world_length(pose_bone, armature_obj):
    """
    Calculate the actual world-space length of a bone accounting for armature
    and parent object scales.
    
    Args:
        pose_bone: The pose bone to measure
        armature_obj: The armature object containing the bone
        
    Returns:
        float: The world-space length of the bone
    """
    # Get the bone's local length
    bone_local_length = pose_bone.length
    
    # Get the armature's world scale
    world_scale = get_world_scale(armature_obj)
    
    # Get the bone's scale
    bone_scale = pose_bone.scale
    
    # Calculate effective world length
    # Use the average of x,y,z scales for uniform scaling approximation
    avg_world_scale = (world_scale.x + world_scale.y + world_scale.z) / 3.0
    avg_bone_scale = (abs(bone_scale.x) + abs(bone_scale.y) + abs(bone_scale.z)) / 3.0
    
    world_length = bone_local_length * avg_world_scale * avg_bone_scale
    
    return world_length


def get_connected_vert_indices(mesh_data, target_index):
    """
    Finds connected vertex indices without using the bmesh module.

    This function works by iterating through the mesh's entire edge list.
    It is much slower than the bmesh equivalent for large meshes.

    Args:
        mesh_data (bpy.types.Mesh): The mesh data to inspect (e.g., obj.data).
        target_index (int): The index of the vertex to find neighbors for.

    Returns:
        list[int]: A list of integer indices for the connected vertices.
    """
    neighbor_indices = set()
    
    for edge in mesh_data.edges:
        v1, v2 = edge.vertices
        
        if v1 == target_index:
            neighbor_indices.add(v2)
        elif v2 == target_index:
            neighbor_indices.add(v1)
            
    return list(neighbor_indices)


def get_connected_verts(vertex):
    """
    Get the first connected vertex to the given vertex.
    
    Args:
        vertex: The vertex to find connections for
        
    Returns:
        The first connected vertex found, or None
    """
    mesh = vertex.id_data
    connected_indices = get_connected_vert_indices(mesh, vertex.index)
    if connected_indices:
        return mesh.vertices[connected_indices[0]]
    return None


def debounce(wait_time):
    """Create a debounced version of a function that delays execution."""
    def decorator(function):
        def debounced(arg, arg2, arg3 , arg4):
            def call_function():
                debounced._timer = None
                return function(arg, arg2, arg3 , arg4)

            if debounced._timer is not None:
                debounced._timer.cancel()

            debounced._timer = threading.Timer(wait_time, call_function)
            debounced._timer.start()

        debounced._timer = None
        return debounced

    return decorator



def generate_spaced_values(n, start=0.0, end=1.0):
    """
    Generates N values equally spaced between start and end.
    """
    return np.linspace(start, end, n)


def setup_bone_dynamics_collection(context):
    """
    Ensure the BoneDynamics collection exists and is properly configured.
    
    Args:
        context: The Blender context
    """
    collection = get_or_create_collection("BoneDynamics")
    context.view_layer.active_layer_collection = collection
    collection.exclude = False
    collection.hide_viewport = False


def ensure_collection_exists(context):
    """
    Create the BoneDynamics collection if it doesn't exist.
    
    Args:
        context: The Blender context
    """
    if not any(collection.name == "BoneDynamics" for collection in bpy.data.collections):
        new_collection = bpy.data.collections.new("BoneDynamics")
        context.scene.collection.children.link(new_collection)


def get_or_create_collection(collection_name):
    """
    Get or create a collection and set it as active.
    
    Args:
        collection_name: Name of the collection
        
    Returns:
        The layer collection for the specified collection
    """
    if collection_name in bpy.context.view_layer.layer_collection.children:
        root = bpy.context.view_layer.layer_collection.children[collection_name]
    else:
        coll = bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(coll)
        root = bpy.context.view_layer.layer_collection.children[coll.name]

    bpy.context.view_layer.active_layer_collection = root
    return root


def find_chain_root(self, context):
    """
    Find the root bone of the selected bone chain.
    """
    def ensure_visible(p_bone):
        # 1. Unhide the bone if it was manually hidden (H key)
        p_bone.bone.hide = False
        # 2. Make sure its bone collections are visible (Blender 4.0+)
        for coll in p_bone.bone.collections:
            coll.is_visible = True

    if len(context.selected_pose_bones) == 1:
        parent = context.active_pose_bone.parent
        if parent:
            ensure_visible(parent)
            if bpy.app.version >= (4, 6, 0):
                parent.select = True
            else:
                parent.bone.select = True
        return parent
        
    for num, bone in enumerate(context.selected_pose_bones):
        if bone.parent in context.selected_pose_bones:
            continue
        else:
            if bone.parent:
                ensure_visible(bone.parent)
                # bone.parent.bone.select = True
                if bpy.app.version >= (4, 6, 0):
                    bone.parent.select = True
                else:
                    bone.parent.bone.select = True
                return bone.parent
            else:
                if len(context.selected_pose_bones) == 2 and bone.parent != context.active_pose_bone:
                    return context.active_pose_bone
                return bone


def main(self, context):
    """
    Main function to add bone dynamics to selected bones.
    
    Args:
        self: The operator instance
        context: The Blender context
    """
    bone_data_list = []
    previous_layers = []
    active = context.object.data.bones.active
    armature = context.active_object

    if bpy.context.scene.sync_mode != 'NONE':
        self.report({'ERROR'}, 'Physics requires the timeline playback mode to be "Play Every Frame". Current mode is incompatible.')
        return;

    if len(bpy.context.selected_pose_bones) == 1 and bpy.context.scene.dynamicParent ==True:
        self.report({'ERROR'}, 'The dynamic parent feature requires at least 2 selected bones, the active one will be the parent.')
        return;

    if len(bpy.context.selected_pose_bones) < 2 and bpy.context.scene.chainMode ==True:
        self.report({'ERROR'}, 'The chain mode requires at least 2 selected bones.')
        return;
    if len(bpy.context.selected_pose_bones) > 0:
        for num, pose_bone in enumerate(context.selected_pose_bones):
            if len(bpy.context.selected_pose_bones) > 0:
                obj = pose_bone.id_data
                armature_name = pose_bone.id_data.name
                
                # Calculate matrices
                translation_tail = Matrix.Translation(pose_bone.tail - pose_bone.head)
                translation_head = Matrix.Translation(1.0 * (pose_bone.tail - pose_bone.head))
                translation_origin = Matrix.Translation(0 * (pose_bone.tail - pose_bone.head))
                
                matrix_head = obj.matrix_world @ (translation_head @ pose_bone.matrix)
                matrix_tail = obj.matrix_world @ (translation_origin @ pose_bone.matrix)
                matrix_final = obj.matrix_world @ (translation_tail @ pose_bone.matrix)

                # Store displacement info
                if not context.scene.chainMode and pose_bone.displace:
                    pose_bone.displaceOrg = pose_bone.bone.use_connect
                    
                # Toggle bone connection
                if not pose_bone.id_data.override_library: 
                    toggle_bone_connection(self, context, pose_bone, False)
                    
                # Determine parent bone
                if context.scene.dynamicParent:
                    parent_bone = context.active_pose_bone
                else:
                    parent_bone = pose_bone.parent
                
                item = [
                    pose_bone.name,
                    num,
                    pose_bone.tail,
                    pose_bone.length,
                    pose_bone.head,
                    matrix_final,
                    parent_bone,
                    armature_name,
                    matrix_head,
                    matrix_tail,
                    pose_bone
                ]

                if context.scene.dynamicParent and pose_bone == context.active_pose_bone:
                    continue
                else:
                    bone_data_list.append(item)
        
        setup_bone_dynamics_collection(context)
        
        if context.scene.chainMode:
            create_chain_physics(self, context, previous_layers)
        else:
            create_individual_physics(self, context, bone_data_list, previous_layers)
    else:
        self.report({'ERROR'}, 'Selection is empty, please select at least two bones.')


def toggle_bone_connection(self, context, pose_bone, should_connect):
    """
    Toggle the connection state of a bone.
    
    Args:
        self: The operator instance
        context: The Blender context
        pose_bone: The pose bone to modify
        should_connect: Whether to connect the bone
    """
    if context.scene.chainMode:
        return False
        
    armature = pose_bone.id_data
    bpy.ops.object.mode_set(mode='EDIT')
    
    if pose_bone.displace:
        armature.data.edit_bones[pose_bone.name].use_connect = False
        
    if should_connect == True and pose_bone.displace == pose_bone.displaceOrg:
        armature.data.edit_bones[pose_bone.name].use_connect = pose_bone.displaceOrg
        
    bpy.ops.object.mode_set(mode='POSE')


def setDefault(self, context):
    """Reset bone dynamics parameters to default values."""
    bones = context.selected_pose_bones
    for bone in bones:
        if context.scene.chainMode:
            bone.boneMass = 0.1
            bone.boneFriction = 4.0
            bone.boneStiffness = 5.0
            bone.boneDamping = 10
            bone.boneBend = 10  
            bone.boneSpeed = 1  
            bone.boneStrength = 0.5
            bone.boneElasticity = 0.00
            bone.collisionDistance = 0.01
            bone.boneGravity = 1.0

        else:
            bone.boneMass = 0.1
            bone.boneFriction = 4.0
            bone.boneStiffness = 5.0
            bone.boneDamping = 10
            bone.boneBend = 10  
            bone.boneSpeed = 1  
            bone.boneStrength = 0.5
            bone.boneElasticity = 0.00
            bone.collisionDistance = 0.01
            bone.boneGravity = 1.0




def updateDisplace(self, context):
    """Update displacement setting for selected bones."""
    if context.mode == 'POSE' and len(context.selected_pose_bones) > 0:
        bones = context.selected_pose_bones
        value = getattr(self, 'displace')
        updateRestBones(self, bones, 'displace' , value)


def updateDisplaceValue(self, context):
    """Update mass property for physics modifiers."""
    try:
       
        bones = context.selected_pose_bones
        value = getattr(self, 'headDisplace')
        updateRestBones(self, bones, 'headDisplace', value)
       
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            
            if obj:
                
                bns =  obj.get('bonesChain', None)
                if bns:
                    return
                
                obj.update_tag()
                obj.hide_render = obj.hide_render
        

    except:
        return



def updateToggle(self, context):
    """Update the influence of bone dynamics constraints."""
    bones = context.selected_pose_bones
    value = getattr(self, 'toggleDynamics')
    updateRestBones(self, bones, 'toggleDynamics' , value)


def updateChain(self, context):
    """Update chain mode settings."""
    print('chain mode is on')
    # setDefault(self, context)
   

@debounce(0.1)
def updateChainBones( bones,armature, prop, value ):

    pose_bones = armature.pose.bones
    
    for bone in bones:
        if bone :
            bone = pose_bones[bone]
            setattr(bone, prop, value) 
            
            


@debounce(0.1)
def updateRestBones(self, bones, prop , value):
    """
    Update a property across multiple bones with debouncing.
    
    Args:
        self: The bone with the source value
        bones: List of bones to update
        prop: Property name to update
    """

    value = getattr(self, prop)
    for bone in bones:
        if bone.name != self.name:
            setattr(bone, prop, value)
         
            



def check_presets():
    """
    Checks for the addon's presets in the user's preset directory,
    and copies them from the addon's folder if they don't exist.
    """
    try:
        addon_presets_path = None
        
        if bpy.app.version < (4, 2, 0):
            addon_presets_path = os.path.join(bpy.utils.script_path_user(), 'addons', 'bonedynamics_pro', 'presets')
            user_presets_path = os.path.join(bpy.utils.script_path_user(), 'presets', 'bonedynamics')
        else:
            extensions_base_path = bpy.utils.user_resource("EXTENSIONS")
            user_default_path = os.path.join(extensions_base_path, 'user_default', 'bonedynamics_pro', 'presets')
            system_path = os.path.join(extensions_base_path, 'system', 'bonedynamics_pro', 'presets')

            if os.path.isdir(user_default_path):
                addon_presets_path = user_default_path
            elif os.path.isdir(system_path):
                addon_presets_path = system_path
            
            user_presets_path = os.path.join(bpy.utils.script_path_user(), 'presets', 'bonedynamics')

        os.makedirs(user_presets_path, exist_ok=True)

        if not addon_presets_path or not os.path.isdir(addon_presets_path):
            print(f"BoneDynamics presets source not found.")
            if bpy.app.version >= (4, 2, 0):
                print(f"Checked path 1: {user_default_path}")
                print(f"Checked path 2: {system_path}")
            return

        for filename in os.listdir(addon_presets_path):
            source_file = os.path.join(addon_presets_path, filename)
            destination_file = os.path.join(user_presets_path, filename)

            if os.path.isfile(source_file):
                if not os.path.exists(destination_file):
                    shutil.copy2(source_file, destination_file)
                    print(f"Copied preset: {filename}")

    except (IOError, OSError) as e:
        print(f"An error occurred during BoneDynamics preset setup: {e}")


def updateMass(self, context):
    """Update mass property for physics modifiers."""
    try:
       
        bones = context.selected_pose_bones
        value = getattr(self, 'boneMass')
        updateRestBones(self, bones, 'boneMass', value)
       
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            
            if obj:
                
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneMass', value )
                
                obj.update_tag()
                obj.hide_render = obj.hide_render
        

    except:
        return


def updateFriction(self, context):
    """Update friction property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneFriction')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneFriction', value )
                obj.update_tag()
        updateRestBones(self, bones, 'boneFriction' , value)
    except:
        return


def updateSpeed(self, context):
    """Update speed property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneSpeed')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneSpeed', value )
                obj.update_tag()
            
        updateRestBones(self, bones, 'boneSpeed' , value)
    except:
        return


def updateGravity(self, context):
    """Update gravity property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneGravity')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneGravity', value )
                obj.update_tag()
        updateRestBones(self, bones, 'boneGravity' , value)
    except:
        return


def updateStiffness(self, context):
    """Update stiffness property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneStiffness')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneStiffness', value )
                obj.update_tag()


        updateRestBones(self, bones, 'boneStiffness' , value)
    except:
        return


def updateElasticity(self, context):
    """Update elasticity property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneElasticity')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneElasticity', value )
                obj.update_tag()
        updateRestBones(self, bones, 'boneElasticity' , value)
    except:
        return


def updateDamping(self, context):
    """Update damping property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneDamping')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneDamping', value )
                obj.update_tag()
        updateRestBones(self, bones, 'boneDamping' , value)
    except:
        return


def updateStrength(self, context):
    """Update strength property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneStrength')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneStrength', value )
                obj.update_tag()
        updateRestBones(self, bones, 'boneStrength' , value)
    except:
        return



def getBend(self , value, is_set):
    return self.get("boneBend", 0.0)

def updateBend(self, context):
    """Update bend property for physics modifiers."""
    try:
        bones = context.selected_pose_bones
        value = getattr(self, 'boneBend')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'boneBend', value )
                obj.update_tag()
                        
        updateRestBones(self, bones, 'boneBend')
    except:
        return


def updateRadius(self, context):
    """Update collision radius for cloth modifiers."""
    try:
        
        bones = context.selected_pose_bones
        value = getattr(self, 'collisionDistance')
        for num, bone in enumerate(bones):
            obj = getattr(bone, "bbdObject")
            if obj:
                bns =  obj.get('bonesChain', None)
                if bns:
                    armature = bone.id_data
                    updateChainBones(bns, armature, 'collisionDistance', value )
                obj.update_tag()
        updateRestBones(self, bones, 'collisionDistance')
    except:
        return


def create_individual_physics(self, context, bone_data_list, previous_layers):
    """
    Create physics objects for individual bones (non-chain mode).
    
    Args:
        self: The operator instance
        context: The Blender context
        bone_data_list: List of bone data to process
        previous_layers: Previous layer visibility state
    """
    armature = context.active_object
    parent = find_chain_root(self, context)
    origin = bpy.context.scene.cursor.location.copy()
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    for bone_data in bone_data_list:
        bone_name = bone_data[0]
        armature_name = bone_data[7]
        pose_bone = bone_data[10]
        
        object_name = bone_name + '|' + armature_name
        existing_obj = context.scene.objects.get(object_name)
        
        if existing_obj:
            # root_collection = get_or_create_collection('BoneDynamics')
            # bpy.context.layer_collection.children['BoneDynamics'].exclude = False
            continue

        root_collection = get_or_create_collection('BoneDynamics')
        mesh = bpy.data.meshes.new("mesh")
        bone_object = bpy.data.objects.new(object_name, mesh)
        
        bpy.ops.object.select_all(action='DESELECT')
        bpy.data.collections['BoneDynamics'].objects.link(bone_object)
        bpy.context.view_layer.objects.active = bone_object
        bone_object.select_set(True)

        #  item = [
        #             pose_bone.name,
        #             num,
        #             pose_bone.tail,
        #             pose_bone.length,
        #             pose_bone.head,
        #             matrix_final,
        #             parent_bone,
        #             armature_name,
        #             matrix_head,
        #             matrix_tail,
        #             pose_bone
        #         ]
        
        # Calculate bone length in world space accounting for all scales
        world_bone_length =  get_bone_world_length(pose_bone, armature)
        
        start = Vector()
        end = Vector((0, 0, world_bone_length))
        verts = (start, end)
        edges = ([0, 1], [1, 0])
        mesh.from_pydata(verts, edges, [])
        
        mesh_data = bone_object.data

        
        # Create vertex groups
        pin_group = bone_object.vertex_groups.new(name="Pin")
        fall_group = bone_object.vertex_groups.new(name="Fall")
        root_group = bone_object.vertex_groups.new(name="Root")
        
        if pose_bone.displace:
            displace_group = bone_object.vertex_groups.new(name="Displace")
            bone_object.vertex_groups[displace_group.index].add([0], 0.5, 'REPLACE')
            bone_object.vertex_groups[displace_group.index].add([1], 0.5, 'REPLACE')
        
        bone_object.vertex_groups[pin_group.index].add([0], 1.0, 'REPLACE')
        bone_object.vertex_groups[pin_group.index].add([1], 0.5, 'REPLACE')
        bone_object.vertex_groups[root_group.index].add([0], 1.0, 'REPLACE')
        bone_object.vertex_groups[fall_group.index].add([1], 1.0, 'REPLACE')

       
        # pose_bone['dynamics'] = True
        # pose_bone['bbdObject'] = bone_object
        setattr(pose_bone, "bbdObject", bone_object)
        setattr(pose_bone, "dynamics", True)
        
        bone_object.hide_render = True
        bone_object.visible_camera = False
        bone_object.visible_shadow = False

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.ed.undo_push()
        
        current_object = context.active_object


        bone_world_matrix = armature.convert_space(
            pose_bone=pose_bone,
            matrix=pose_bone.matrix,
            from_space="POSE",
            to_space="WORLD"
        )
        rotation_matrix = Matrix.Rotation(math.radians(-90.0), 4, 'X')
        current_object.matrix_world = bone_world_matrix @ rotation_matrix

        
        

        current_object['dynamics'] = True
        current_object['arma'] = armature.id_data
        current_object['bone'] = pose_bone.name
        # setattr(current_object, "dynamics", True)
        # setattr(current_object, "bone", pose_bone.name)
        # setattr(current_object, "arma", armature.id_data)
        
        
        bnscale=  (world_bone_length * armature.scale.x) * 0.001
        add_cloth_physics(self, context, current_object, pose_bone, bnscale)

        # current_object.
        
        current_object.hide_render = True

        bpy.ops.ed.undo_push()
        current_object.select_set(True)
        armature.select_set(True)
        bpy.context.view_layer.objects.active = armature
        
        # Parent to bone
        parent_bone = bone_data[6]
        if parent_bone:
            parent_name = parent_bone.name
            if parent_name:
                parent_pose_bone = armature.pose.bones.get(parent_name)
                current_object.parent = armature
                current_object.parent_type = "BONE"
                current_object.parent_bone = parent_name
                
                parent_matrix = armature.matrix_world @ Matrix.Translation(
                    1 * (parent_pose_bone.tail - parent_pose_bone.head)
                ) @ parent_pose_bone.matrix
                current_object.matrix_parent_inverse = parent_matrix.inverted()
                
                # Apply bone scale to maintain proper proportions
                current_object.scale = pose_bone.scale

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        current_object.display_type = 'WIRE'
        current_object.hide_render = True

    bpy.ops.object.mode_set(mode='POSE')
    
    # Add constraints
    constraint_type = 'STRETCH_TO' if context.scene.boneStretch else 'DAMPED_TRACK'
    constraint_type_displace = 'COPY_LOCATION'
    
    for bone_data in bone_data_list:
        pose_bone = bone_data[10]
        object_name = pose_bone.name + '|' + pose_bone.id_data.name
        physics_object = bpy.data.objects[object_name]
        
        if pose_bone.displace:
            displace_constraint_name = 'BoneDynamics-displace-' + pose_bone.name
            displace_constraint = (
                pose_bone.constraints.get(displace_constraint_name)
                or pose_bone.constraints.new(type=constraint_type_displace)
            )
            displace_constraint.target = physics_object
            displace_constraint.subtarget = "Root"
            displace_constraint.name = displace_constraint_name
        
        main_constraint_name = 'BoneDynamics-damped-' + pose_bone.name
        main_constraint = (
            pose_bone.constraints.get(main_constraint_name)
            or pose_bone.constraints.new(type=constraint_type)
        )
        
        main_constraint.target = physics_object
        main_constraint.subtarget = "Fall"
        main_constraint.name = 'BoneDynamics-damped-' + bone_data[0]
        
        
        context_py = bpy.context.copy()
        context_py["constraint"] = main_constraint
        if parent:
            if bpy.app.version >= (4, 6, 0):
                parent.select = False
            else:
                parent.bone.select = False
        add_bdp_drivers(self, context, pose_bone , None )

        
    if context.scene.bdp_auto_transfer:
        bpy.ops.object.bdp_transfer_animation()


def setup_influence_driver(constraint , pose_bone):
        if constraint is None:
            return
        
        # Add (or retrieve existing) driver for the 'influence' property
        fcurve = constraint.driver_add("influence")
        drv = fcurve.driver
        
        # Set Driver Type
        drv.type = 'SCRIPTED'
        drv.expression = "var"

        # Clear existing variables to ensure we don't stack duplicates if run twice
        # (Blender Python API requires iterating to remove)
        for v in drv.variables:
            drv.variables.remove(v)

        # Create the variable
        var = drv.variables.new()
        var.name = "var"
        var.type = 'SINGLE_PROP'

        # Target the Armature Object (id_data of a pose bone is the Armature Object)
        target = var.targets[0]
        target.id = pose_bone.id_data
        
        # Path to the custom property on this specific pose bone
        # Syntax: pose.bones["BoneName"]["PropertyName"]
        target.data_path = f'pose.bones["{pose_bone.name}"].toggleDynamics'

def setup_physics_driver(context,physics_object , pose_bone, physics_property,bone_property, expression):
        if physics_object is None:
            return


        modifier = physics_object.modifiers.get('Cloth')
        # Add (or retrieve existing) driver for the 'influence' property
        if physics_property == "distance_min":
            fcurve =  modifier.collision_settings.driver_add(physics_property)
        elif physics_property == "gravity":
            fcurve =  modifier.settings.effector_weights.driver_add(physics_property)
        else:
            fcurve =  modifier.settings.driver_add(physics_property)
        drv = fcurve.driver

        # Set Driver Type
        drv.type = 'SCRIPTED'
        drv.expression = expression

        # Clear existing variables to ensure we don't stack duplicates if run twice
        # (Blender Python API requires iterating to remove)
        for v in drv.variables:
            drv.variables.remove(v)

        # Create the variable
        var = drv.variables.new()
        var.name = "var"
        var.type = 'SINGLE_PROP'

        # Target the Armature Object (id_data of a pose bone is the Armature Object)
        target = var.targets[0]
        target.id = pose_bone.id_data

        # Path to the custom property on this specific pose bone
        # Syntax: pose.bones["BoneName"]["PropertyName"]
        target.data_path = f'pose.bones["{pose_bone.name}"].{bone_property}'
        
def add_bdp_drivers(self, context, pose_bone , parent):

    main_constraint_name = 'BoneDynamics-damped-' + pose_bone.name
    displace_constraint_name = 'BoneDynamics-displace-' + pose_bone.name

    displace = pose_bone.constraints.get(displace_constraint_name)
    main = pose_bone.constraints.get(main_constraint_name)
    physics_object = getattr(pose_bone, "bbdObject", None)

    # 1. Ensure the custom property exists on the bone, otherwise driver will be broken (red)
    toggleDynamics = getattr(pose_bone, "toggleDynamics", None)
    if toggleDynamics:
        pose_bone["toggleDynamics"] = 1.0  # Default to On

    displaceOn = getattr(pose_bone, "displace", None)

    if displaceOn and physics_object:
        displace1 = physics_object.modifiers.get('displace-1' , None )
        displace2 = physics_object.modifiers.get('displace-2', None)
        if displace1:
            driver = displace1.driver_add("mask_constant")
            drv = driver.driver
            drv.type = 'SCRIPTED'
            drv.expression = "var"
            var = drv.variables.new()
            var.name = "var"
            var.type = 'SINGLE_PROP'
            target = var.targets[0]
            target.id = pose_bone.id_data
            target.data_path = f'pose.bones["{pose_bone.name}"].headDisplace'
        if displace2:
            driver = displace2.driver_add("mask_constant")
            drv = driver.driver
            drv.type = 'SCRIPTED'
            drv.expression = "1 -var"
            var = drv.variables.new()
            var.name = "var"
            var.type = 'SINGLE_PROP'
            target = var.targets[0]
            target.id = pose_bone.id_data
            target.data_path = f'pose.bones["{pose_bone.name}"].headDisplace'
   
        setup_influence_driver(displace, pose_bone)
   

    # 3. Apply the logic to both constraints
    setup_influence_driver(main, pose_bone)
    

    if parent:
        pose_bone = parent
    setup_physics_driver(context, physics_object, pose_bone , "mass", "boneMass", "var")
    setup_physics_driver(context, physics_object, pose_bone , "bending_stiffness", "boneBend" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "tension_stiffness", "boneBend" ,  "(var + 1)")
    setup_physics_driver(context, physics_object, pose_bone , "shear_stiffness", "boneBend" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "time_scale", "boneSpeed" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "tension_damping", "boneDamping" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "shear_damping", "boneDamping" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "bending_damping", "boneDamping" ,  "var")

    setup_physics_driver(context, physics_object, pose_bone , "pin_stiffness", "boneStiffness" ,  "(exp(var/10) - 1)")
    setup_physics_driver(context, physics_object, pose_bone , "shrink_min", "boneElasticity" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "air_damping", "boneFriction" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "distance_min", "collisionDistance" ,  "var")
    setup_physics_driver(context, physics_object, pose_bone , "gravity", "boneGravity" ,  "var")
      
    # modifier.collision_settings.use_collision = True
    # modifier.collision_settings.collision_quality = 4
    # mod_settings.time_scale = bone.boneSpeed
    # mod_settings.tension_damping = bone.boneDamping
    # mod_settings.shear_damping = bone.boneDamping
    # mod_settings.bending_damping = bone.boneDamping
    # mod_settings.bending_stiffness = bone.boneBend
    # mod_settings.pin_stiffness = math.exp(bone.boneStiffness/10) - 1 
    # mod_settings.shrink_min = bone.boneElasticity
    # mod_settings.mass= bone.boneMass
    # mod_settings.air_damping = bone.boneFriction
    # modifier.collision_settings.distance_min = bone.collisionDistance

    

    

def create_chain_physics(self, context, previous_layers):
    """
    Create physics objects for bone chains (chain mode).
    
    Args:
        self: The operator instance
        context: The Blender context
        previous_layers: Previous layer visibility state
    """
    armature = context.active_object
    parent = find_chain_root(self, context)
    
    # Check for disconnected bones in chain mode
    for num, bone in enumerate(context.selected_pose_bones):
        if bone.bone.use_connect == False and bone != parent:
            self.report({'WARNING'}, "Using chain mode on disconnected bones can lead to errors.")
            break
    
    verts = list()
    edges = list()
    edge_index = 0
    bone_position_dict = []
    tail_weights = {}
    print('selected bones', len(context.selected_pose_bones))
    even_values = generate_spaced_values(len(context.selected_pose_bones) , 0.4 , 0.8)
    ev_values = even_values[::-1]
    # Calculate tail weights for each bone
    for num, bone in enumerate(context.selected_pose_bones):
        recursive = [value for value in bone.children_recursive if value in context.selected_pose_bones]
        # tail_weights[bone.name] = 1 - (len(recursive) / len(context.selected_pose_bones))
        tail_weights[bone.name] =  ev_values[num]

    # Build mesh vertices and edges
    for num, bone in enumerate(context.selected_pose_bones):
        dynamics = getattr(bone, "dynamics", False)
        if dynamics == True:
            continue
        print('preparing matrices')
        translation = Matrix.Translation(bone.tail - bone.head)
        matrix_final = armature.matrix_world @ (translation @ bone.matrix)
        
        translation_head = Matrix.Translation(1.0 * (bone.tail - bone.head))
        translation_tail = Matrix.Translation(0 * (bone.tail - bone.head))
        matrix_head = armature.matrix_world @ (translation_head @ bone.matrix)
        matrix_tail = armature.matrix_world @ (translation_tail @ bone.matrix)
        
        head_position = matrix_head.to_translation()
        tail_position = matrix_tail.to_translation()
        
        verts.append(head_position)
        verts.append(tail_position)
        bone_position_dict.append([bone.name, head_position, tail_position])
        
        # Calculate bone length accounting for world scale
        world_bone_length = get_bone_world_length(bone, armature) / context.scene.boneLength
        
        edges.append([num + edge_index, num + edge_index + 1])
        edges.append([num + edge_index + 1, num + edge_index])
        edge_index += 1
        
        # Determine object name
        if parent:
           
            setattr(bone, "chainParent", parent.name)
            object_name = parent.name + '|' + parent.id_data.name
            if bone != parent:
                setattr(bone, "dynamics", True)
                setattr(bone, "chain", True)
                # bone['dynamics'] = True
                # bone['chain'] = True
                
        else:
            object_name = bone.name + '|' + bone.id_data.name
            setattr(bone, "dynamics", True)
            setattr(bone, "chain", True)
        
        print('bone length:', world_bone_length)
        bpy.ops.ed.undo_push()
        
        # Create mesh object when processing last bone
        if bone == context.selected_pose_bones[-1]:
            mesh = bpy.data.meshes.new(object_name)
            mesh.from_pydata(verts, edges, [])
            physics_object = bpy.data.objects.new(object_name, mesh)
            bpy.data.collections['BoneDynamics'].objects.link(physics_object)
            
            # Link object to all bones
            for selected_bone in context.selected_pose_bones:
                setattr(selected_bone, "bbdObject", physics_object)
                setattr(selected_bone, "chain", True)

            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            context.view_layer.objects.active = physics_object
            physics_object.select_set(True)
            
            physics_object["dynamics"] = True
            physics_object["chain"] = True
            physics_object['arma'] = armature.id_data
            if parent:
                physics_object['MainBone'] = parent.name
            
            
            bpy.context.object.data.validate()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            # print('bone length:', world_bone_length)
            bpy.ops.mesh.remove_doubles(threshold=world_bone_length)
            bpy.ops.object.mode_set(mode='OBJECT')
            
            mesh_data = physics_object.data
            physics_object.hide_render = True
            physics_object.visible_camera = False
            physics_object.visible_shadow = False
            
            parent_bones = get_selected_chain_roots()
            
            # Create vertex groups
            for vertex in mesh_data.vertices:
                for bone_data in bone_position_dict:
                    result = vertex.co - bone_data[1]
                    
                    if result.length < abs(world_bone_length):
                        if bone_data[0] in parent_bones:
                            other_vertex = get_connected_verts(vertex)
                            
                            if not "Pin" in [g.name for g in physics_object.vertex_groups]:
                                pin_group = physics_object.vertex_groups.new(name="Pin")
                                pin_group.add([vertex.index], 1.0, 'REPLACE')
                                # if other_vertex:
                                #     pin_group.add([other_vertex.index], 1.0, 'REPLACE')
                            else:
                                pin_group = physics_object.vertex_groups["Pin"]
                                pin_group.add([vertex.index], 1.0, 'REPLACE')
                                # if other_vertex:
                                #     pin_group.add([other_vertex.index], 1.0, 'REPLACE')
                        
                        group = physics_object.vertex_groups.new(name=bone_data[0])
                        
                        tails_group = (
                            physics_object.vertex_groups.get("tails")
                            or physics_object.vertex_groups.new(name="tails")
                        )
                        
                        pin_group = (
                            physics_object.vertex_groups.get("Pin")
                            or physics_object.vertex_groups.new(name="Pin")
                        )
                        
                        pin_group.add([vertex.index], tail_weights[bone_data[0]], 'REPLACE')
                        
                        physics_object.vertex_groups[group.index].add([vertex.index], 1.0, 'REPLACE')
            
            # Pin vertices without groups
            vertex_group_names = {vgroup.index: vgroup.name for vgroup in physics_object.vertex_groups}
            vertex_groups = {v.index: [vertex_group_names[g.group] for g in v.groups] for v in mesh_data.vertices}
            
            for vertex in mesh_data.vertices:
                if len(vertex_groups[vertex.index]) == 0:
                    if not "Pin" in [g.name for g in physics_object.vertex_groups]:
                        pin_group = physics_object.vertex_groups.new(name="Pin")
                    else:
                        pin_group = physics_object.vertex_groups["Pin"]
                    
                    physics_object.vertex_groups[pin_group.index].add([vertex.index], 1.0, 'REPLACE')
                    # tails_group.add([vertex.index], 1.0, 'REPLACE')
                    other_vertex_indices = get_connected_vert_indices(mesh_data, vertex.index)

                    if other_vertex_indices and context.scene.PinFirst:
                        pin_group.add([other_vertex_indices[0]], 1.0, 'REPLACE')
                        # tails_group.add([other_vertex_indices[0]], 1.0, 'REPLACE')

            bpy.context.object.data.validate()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.context.view_layer.objects.active = armature

            # Parent to armature
            
            if parent:
                parent_pose_bone = armature.pose.bones.get(parent.name)
                physics_object.parent = armature
                physics_object.parent_type = "BONE"
                physics_object.parent_bone = parent.name
                
                parent_matrix = armature.matrix_world @ Matrix.Translation(
                    parent_pose_bone.tail - parent_pose_bone.head
                ) @ parent_pose_bone.matrix
                physics_object.matrix_parent_inverse = parent_matrix.inverted()

            bpy.ops.object.mode_set(mode='POSE')
            bpy.context.view_layer.objects.active = armature
            physics_object['bonesChain'] = [bne.name for bne in context.selected_pose_bones]
            # Add constraints to bones
            for selected_bone in context.selected_pose_bones:
                
                if selected_bone == parent:
                    continue
                
                pose_bone = armature.pose.bones.get(selected_bone.name)
                constraint_name = 'BoneDynamics-damped-' + selected_bone.name
                constraint_type = 'STRETCH_TO' if context.scene.boneStretch else 'DAMPED_TRACK'
                
                constraint = (
                    pose_bone.constraints.get(constraint_name)
                    or pose_bone.constraints.new(type=constraint_type)
                )
                constraint.target = physics_object
                constraint.subtarget = selected_bone.name
                constraint.name = constraint_name
                
                
            
            bpy.ops.object.mode_set(mode='OBJECT')
            
            
            add_cloth_physics(self, context, physics_object, bone, world_bone_length)
            
    
    context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='POSE')

    
    if parent:
        if bpy.app.version >= (4, 6, 0):
            parent.select = False
        else:
            parent.bone.select = False

            
    for selected_bone in context.selected_pose_bones:
        add_bdp_drivers(self, context, selected_bone, parent)

def add_cloth_physics(self, context, physics_object, bone, bone_length):
    """
    Add cloth physics modifier to an object.
    
    Args:
        self: The operator instance
        context: The Blender context
        physics_object: The object to add physics to
        bone: The bone reference
        bone_length: The bone length for extrusion
    """
    bpy.ops.object.select_all(action='DESELECT')
    context.view_layer.objects.active = physics_object
    physics_object.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
    bpy.ops.mesh.select_all(action='SELECT')

    bpy.ops.transform.translate(
        value=(-bone_length / 2, 0, 0), 
        orient_type='GLOBAL',
        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
        orient_matrix_type='GLOBAL'
    )


    bpy.ops.mesh.extrude_region_move(
        MESH_OT_extrude_region={"use_normal_flip": False, "use_dissolve_ortho_edges": False, "mirror": True},
        TRANSFORM_OT_translate={
            "value": (bone_length , 0, 0),
            "orient_type": 'GLOBAL',
            "orient_matrix": ((1, 0, 0), (0, 1, 0), (0, 0, 1)),
            "orient_matrix_type": 'GLOBAL'
        }
    )

    bpy.ops.object.mode_set(mode='OBJECT')
    modifier = physics_object.modifiers.new(name="Cloth", type='CLOTH')
    mod_settings = modifier.settings
    
    mod_settings.bending_model = 'LINEAR'
    modifier.point_cache.frame_start = context.scene.frame_start
    modifier.point_cache.frame_end = context.scene.frame_end
    
    
    mod_settings.vertex_group_mass = "Pin"
    if bone.displace and not context.scene.chainMode:
        mod_settings.vertex_group_mass = "Displace"
        mix_mod = physics_object.modifiers.new(name='displace-1', type='VERTEX_WEIGHT_MIX')
        mix_mod.vertex_group_a = "Displace"
        mix_mod.vertex_group_b = "Pin"
        mix_mod.mix_set = 'B' # Set Mix Set to B
        mix_mod2 = physics_object.modifiers.new(name='displace-2', type='VERTEX_WEIGHT_MIX')
        mix_mod2.vertex_group_a = "Displace"
        mix_mod2.vertex_group_b = "Fall"
        mix_mod2.mix_set = 'B' # Set Mix Set to B
        try:
                # Switch to Object mode to change active object safely
                bpy.ops.object.mode_set(mode='OBJECT')
                
                # Make the bone_object (mesh) active
                context.view_layer.objects.active = physics_object
                
                # Move Hook to index 0 (Top)
                bpy.ops.object.modifier_move_to_index(modifier=mix_mod2.name, index=0)
                
                # Move Mix to index 0 (Top). 
                # This pushes the Hook we just moved to index 1, ensuring Mix is before Hook.
                bpy.ops.object.modifier_move_to_index(modifier=mix_mod.name, index=0)
                
        except Exception as e:
                self.report({'WARNING'}, f"Could not reorder modifiers: {str(e)}")

        
    mod_settings.quality = 10
    modifier.collision_settings.use_collision = True
    modifier.collision_settings.collision_quality = 4
    mod_settings.time_scale = bone.boneSpeed
    mod_settings.tension_damping = bone.boneDamping
    mod_settings.shear_damping = bone.boneDamping
    mod_settings.bending_damping = bone.boneDamping
    mod_settings.bending_stiffness = bone.boneBend
    mod_settings.pin_stiffness = math.exp(bone.boneStiffness/10) - 1 
    mod_settings.shrink_min = bone.boneElasticity
    mod_settings.mass= bone.boneMass
    mod_settings.air_damping = bone.boneFriction
    modifier.collision_settings.distance_min = bone.collisionDistance

  

    bpy.ops.object.select_all(action='DESELECT')
    





def clearScene(self, context):
    """
    Remove bone dynamics from selected bones.
    
    Args:
        self: The operator instance
        context: The Blender context
    """
    bone_names = []

    
    
    for bone in bpy.context.selected_pose_bones:
        for constraint in bone.constraints:
            if constraint.name == 'BoneDynamics-damped-' + bone.name or constraint.name == "BoneDynamics-displace-" + bone.name:
                if constraint.name == "BoneDynamics-displace-" + bone.name:
                    if not bone.id_data.override_library:
                        toggle_bone_connection(self, context, bone, True)
                bone.constraints.remove(constraint)
                object_name = bone.name + '|' + bone.id_data.name
                bone_names.append(object_name)
        
        try:
            physics_object = getattr(bone, "bbdObject")
            bonesChain = physics_object.get('bonesChain')
            print('found bonechain,' , bonesChain)
            armature = bone.id_data
            pose_bones = armature.pose.bones
            if bonesChain:
                for bn in bonesChain:
                    bbn = pose_bones.get(bn)
                    for constraint in bbn.constraints:
                        if constraint.name == 'BoneDynamics-damped-' + bbn.name or constraint.name == "BoneDynamics-displace-" + bbn.name:
                            if constraint.name == "BoneDynamics-displace-" + bbn.name:
                                if not bbn.id_data.override_library:
                                    toggle_bone_connection(self, context, bone, True)
                            bbn.constraints.remove(constraint)
                            object_name = bbn.name + '|' + bbn.id_data.name
                            bone_names.append(object_name)
        except:
            print('Not a chain')

        try:
            physics_object = getattr(bone, "bbdObject")
            bpy.data.objects.remove(physics_object, do_unlink=True)
        except:
            print('object not found')
        
        try:
            for obj in bpy.data.collections['BoneDynamics'].objects:
                if obj.name in bone_names:
                    bpy.data.objects.remove(bpy.context.scene.objects[obj.name], do_unlink=True)
        except:
            print('object not found')
        
        try:
            del bone['chain']
        except:
            print('property not found')
        
        try:

            del bone['displace']
        except:
            print('property not found')
        
        try:
            # setattr(bone, "dynamics", False)
            del bone['dynamics']
            del bone['bbd-parent']
        except:
            print('property not found')
        
        try:
            setattr(bone, "dynamics", False)
            setattr(bone, "chain", False)
            setattr(bone, "displace", False)
            setattr(bone, "chainParent", "None")

        except:
            print('property not found')
    
    if len(bpy.data.collections['BoneDynamics'].objects) < 1:
        coll = bpy.data.collections.get('BoneDynamics')
        bpy.data.collections.remove(coll)
    
    bone_names.clear()


class SyncTimeRange(bpy.types.Operator):
    """If you have changed the timeline range,with dynamic bones already in your scene, select them and use this to sync the physics cache."""
    bl_idname = "object.sync_timerange"
    bl_label = "Sync Time Range"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        if context.mode == 'POSE' and len(context.selected_pose_bones) > 0:
            return True
        else:
            return False
    
    def sync_timerange(self, context):
        """Synchronize timeline range with physics cache."""
        armature = context.active_object
        start = context.scene.frame_start
        end = context.scene.frame_end
        objects_list = []
        
        for bone in bpy.context.selected_pose_bones:
            bone_object = getattr(bone, "bbdObject", None)
            if bone_object:
                objects_list.append(bone_object)
        
        if len(objects_list) > 0:
            for obj in objects_list:
                for modifier in obj.modifiers:
                    if modifier.type == "SOFT_BODY" or modifier.type == "CLOTH":
                        modifier.point_cache.frame_start = start
                        modifier.point_cache.frame_end = end
    
    def execute(self, context):
        self.sync_timerange(context)
        return {'FINISHED'}



class AddControlPoint(bpy.types.Operator):
    """Add a control point to the selected bone"""
    bl_idname = "object.bdp_add_control_point"
    bl_label = "Add Control Point"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Only allow if we are in pose mode and have a valid bone selected
        if context.mode != 'POSE' or not context.active_pose_bone:
            return False
            
        # Check for chain attribute (as per your snippet)
        chain = getattr(context.active_pose_bone, "chain", None)
        if not chain:
            return False
            # # You had a commented out line and a check for bbdObject
            # # Assuming we need bbdObject to exist to proceed
            # if hasattr(context.active_pose_bone, "bbdObject"):
            #     return True
        return True

    

    def add_control_point(self, context):
        """Add a control point to the selected bone. Chain mode only"""
        bone = context.active_pose_bone
        bone_object = getattr(bone, "bbdObject", None)
        armature_obj = context.object
        
        if bone_object:
            print('control point added', bone_object.name)

            # 1. Create the Empty
            empty_name = f"hook-{bone.name}"
            # Check if it already exists to avoid duplicates or error
            if empty_name in bpy.data.objects:
                empty_obj = bpy.data.objects[empty_name]
            else:
                empty_obj = bpy.data.objects.new(empty_name, None)
                context.collection.objects.link(empty_obj)

            # 2. Position the Empty at the tip (tail) of the bone
            # We must multiply armature world matrix by bone tail position (local)
            empty_obj.location = armature_obj.matrix_world @ bone.tail
            empty_obj.empty_display_size = 0.5  # Optional: make it visible
            empty_obj.empty_display_type = 'PLAIN_AXES'

            # 3. Add Hook Modifier
            hook_mod_name = f"hook-{bone.name}"
            # Remove if exists to prevent stacking duplicates
            for mod in bone_object.modifiers:
                if mod.name == hook_mod_name:
                    bone_object.modifiers.remove(mod)

            hook_mod = bone_object.modifiers.new(name=hook_mod_name, type='HOOK')
            bpy.context.evaluated_depsgraph_get()
            hook_mod.object = empty_obj
            hook_mod.vertex_group = bone.name
            
            # 4. Add Vertex Weight Mix Modifier
            mix_mod_name = f"mix-{bone.name}"
            # Remove if exists
            for mod in bone_object.modifiers:
                if mod.name == mix_mod_name:
                    bone_object.modifiers.remove(mod)

            mix_mod = bone_object.modifiers.new(name=mix_mod_name, type='VERTEX_WEIGHT_MIX')
            mix_mod.vertex_group_a = "Pin"
            mix_mod.vertex_group_b = bone.name
            mix_mod.mix_set = 'B' # Set Mix Set to B
            
            # 5. Handle Modifier Ordering (Move to First)
            # To use modifier_move_to_index, the mesh object must be the active object.
            
            # Save current state
            saved_active_obj = context.view_layer.objects.active
            saved_mode = context.mode

            try:
                # Switch to Object mode to change active object safely
                bpy.ops.object.mode_set(mode='OBJECT')
                
                # Make the bone_object (mesh) active
                context.view_layer.objects.active = bone_object
                
                # Move Hook to index 0 (Top)
                bpy.ops.object.modifier_move_to_index(modifier=hook_mod.name, index=0)
                
                # Move Mix to index 0 (Top). 
                # This pushes the Hook we just moved to index 1, ensuring Mix is before Hook.
                bpy.ops.object.modifier_move_to_index(modifier=mix_mod.name, index=0)
                
            except Exception as e:
                self.report({'WARNING'}, f"Could not reorder modifiers: {str(e)}")
            
            finally:
                # Restore previous state (Back to Armature and Pose Mode)
                context.view_layer.objects.active = saved_active_obj
                if saved_mode == 'POSE':
                    bpy.ops.object.mode_set(mode='POSE')
                elif saved_mode != 'OBJECT':
                    # Fallback for other modes if necessary
                    bpy.ops.object.mode_set(mode=saved_mode)

    def execute(self, context):
        self.add_control_point(context)
        return {'FINISHED'}

class TransferAnimation(bpy.types.Operator):
    """If the bone has keyframes, use this to transfer them to the dynamic bone."""
    bl_idname = "object.bdp_transfer_animation"
    bl_label = "Transfer Animation"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        if context.mode != 'POSE' or not context.selected_pose_bones:
            return False
        active_bone = context.active_pose_bone
        if not active_bone:
            return False
        chain = getattr(active_bone, "chain", None)
        if chain:
            return False
        return hasattr(active_bone, "bbdObject")
    
    # -------------------------------------------------------------------------
    # FCurve Compatibility Layer
    # -------------------------------------------------------------------------
    
    def get_fcurves(self, obj):
        """Get fcurves compatible with Blender 4.4+, 4.5+ and earlier versions."""
        anim_data = obj.animation_data
        if not anim_data or not anim_data.action:
            return None
        
        action = anim_data.action
        
        # Blender 4.4+ with slotted actions
        if bpy.app.version >= (4, 4, 0):
            return self._get_fcurves_slotted(anim_data, action)
        
        # Pre-4.4: direct fcurves access
        return action.fcurves
    
    def _get_fcurves_slotted(self, anim_data, action):
        """Get fcurves for slotted action system (Blender 4.4+)."""
        # Try bpy_extras.anim_utils first (Blender 4.5+)
        try:
            from bpy_extras import anim_utils
            if hasattr(anim_utils, 'action_get_channelbag_for_slot'):
                channelbag = anim_utils.action_get_channelbag_for_slot(
                    action, anim_data.action_slot
                )
                if channelbag:
                    return channelbag.fcurves
        except (ImportError, AttributeError):
            pass
        
        # Fallback: direct access (Blender 4.4)
        try:
            if action.layers and action.layers[0].strips and action.slots:
                strip = action.layers[0].strips[0]
                channelbag = strip.channelbag(action.slots[0])
                if channelbag:
                    return channelbag.fcurves
        except (AttributeError, IndexError, TypeError):
            pass
        
        return None
    
    def get_or_create_channelbag(self, obj, action):
        """Get or create channelbag for object, compatible with all versions."""
        anim_data = obj.animation_data
        
        if bpy.app.version >= (4, 4, 0):
            # Try bpy_extras.anim_utils first (Blender 4.5+)
            try:
                from bpy_extras import anim_utils
                if hasattr(anim_utils, 'action_get_channelbag_for_slot'):
                    channelbag = anim_utils.action_get_channelbag_for_slot(
                        action, anim_data.action_slot
                    )
                    if channelbag:
                        return channelbag
            except (ImportError, AttributeError):
                pass
            
            # Fallback for 4.4
            try:
                if not action.layers:
                    layer = action.layers.new(name="Layer")
                else:
                    layer = action.layers[0]
                
                if not layer.strips:
                    strip = layer.strips.new(type='KEYFRAME')
                else:
                    strip = layer.strips[0]
                
                slot = anim_data.action_slot
                if slot is None:
                    slot = action.slots.new(id_type='OBJECT', name=obj.name)
                    anim_data.action_slot = slot
                
                channelbag = strip.channelbag(slot)
                if channelbag is None:
                    channelbag = strip.channelbags.new(slot=slot)
                
                return channelbag
            except (AttributeError, TypeError) as e:
                print(f"Warning: Could not create channelbag: {e}")
                return None
        
        return None
    
    def create_fcurves(self, obj, action, data_path, count):
        """Create fcurves compatible with all Blender versions."""
        fcurves_list = []
        
        if bpy.app.version >= (4, 4, 0):
            channelbag = self.get_or_create_channelbag(obj, action)
            if channelbag:
                for i in range(count):
                    fc = channelbag.fcurves.new(data_path=data_path, index=i)
                    fcurves_list.append(fc)
                return fcurves_list
        
        # Pre-4.4: direct fcurves access
        for i in range(count):
            fc = action.fcurves.new(data_path=data_path, index=i)
            fcurves_list.append(fc)
        
        return fcurves_list
    
    # -------------------------------------------------------------------------
    # Keyframe Collection
    # -------------------------------------------------------------------------
    
    def get_bone_keyframe_times(self, armature, bone_name):
        """Get all unique keyframe times for a specific bone."""
        fcurves = self.get_fcurves(armature)
        if not fcurves:
            return []
        
        bone_path = f'pose.bones["{bone_name}"]'
        times = set()
        
        for fc in fcurves:
            if fc.data_path.startswith(bone_path):
                for kp in fc.keyframe_points:
                    times.add(int(kp.co.x))
        
        return sorted(times)
    
    def get_keyframe_interpolation_data(self, armature, bone_name):
        """Get keyframe times along with their interpolation types."""
        fcurves = self.get_fcurves(armature)
        if not fcurves:
            return {}
        
        bone_path = f'pose.bones["{bone_name}"]'
        keyframe_data = {}
        
        for fc in fcurves:
            if fc.data_path.startswith(bone_path):
                for kp in fc.keyframe_points:
                    frame = int(kp.co.x)
                    if frame not in keyframe_data:
                        keyframe_data[frame] = kp.interpolation
        
        return keyframe_data
    
    # -------------------------------------------------------------------------
    # Animation Transfer
    # -------------------------------------------------------------------------
    
    def transfer_bone_animation(self, context, bone, armature):
        """Transfer animation from a single bone to its physics object efficiently."""
        physics_object = getattr(bone, "bbdObject", None)
        if not physics_object:
            return False, "No physics object"
        
        if not getattr(bone, "dynamics", False):
            return False, "Not a dynamic bone"
            
        pose_bone = armature.pose.bones[bone.name]
        
        # --- 1. ANALYZE SOURCE CURVES ---
        fcurves = self.get_fcurves(armature)
        if not fcurves:
            return False, "No animation data found"

        bone_path = f'pose.bones["{bone.name}"]'
        
        frames_loc = set()
        frames_rot = set()
        frames_scale = set()
        frame_interp = {} 

        for fc in fcurves:
            if not fc.data_path.startswith(bone_path):
                continue
                
            is_loc = "location" in fc.data_path
            is_rot = "rotation" in fc.data_path
            is_scale = "scale" in fc.data_path
            
            if not (is_loc or is_rot or is_scale):
                continue

            for kp in fc.keyframe_points:
                frame = int(kp.co.x)
                frame_interp[frame] = kp.interpolation
                
                if is_loc: frames_loc.add(frame)
                elif is_rot: frames_rot.add(frame)
                elif is_scale: frames_scale.add(frame)

        all_frames = sorted(list(frames_loc | frames_rot | frames_scale))
        if not all_frames:
            return False, "No keyframes on bone"

        # --- 2. PREPARE OBJECT ---
        constraint_names = [f'BoneDynamics-damped-{bone.name}', f'BoneDynamics-displace-{bone.name}']
        constraints = [(bone.constraints.get(name), name) for name in constraint_names]
        for c, _ in constraints:
            if c: c.enabled = False

        bpy.ops.object.mode_set(mode='OBJECT')
        context.scene.frame_set(context.scene.frame_start)
        
        # Create animation data directly without touching parent relationships
        if not physics_object.animation_data:
            physics_object.animation_data_create()
        action = bpy.data.actions.new(name=f"{physics_object.name}_Action")
        physics_object.animation_data.action = action

        loc_curves = self.create_fcurves(physics_object, action, "location", 3) if frames_loc else []
        rot_curves = self.create_fcurves(physics_object, action, "rotation_euler", 3) if frames_rot else []
        scale_curves = self.create_fcurves(physics_object, action, "scale", 3) if frames_scale else []
        
        for fc in loc_curves: fc.keyframe_points.add(len(frames_loc))
        for fc in rot_curves: fc.keyframe_points.add(len(frames_rot))
        for fc in scale_curves: fc.keyframe_points.add(len(frames_scale))

        # --- 3. TRANSFER DATA ---
        idx_loc = 0
        idx_rot = 0
        idx_scale = 0
        prev_euler = None
        for frame in all_frames:
            context.scene.frame_set(frame)
            interp = frame_interp.get(frame, 'BEZIER')

            if frame in frames_loc or frame in frames_rot:
                # 1. Get the target world position from the bone
                bone_world_matrix = armature.convert_space(
                    pose_bone=pose_bone,
                    matrix=pose_bone.matrix,
                    from_space="POSE",
                    to_space="WORLD"
                )
                rotation_matrix = Matrix.Rotation(math.radians(-90.0), 4, 'X')
                target_world_matrix = bone_world_matrix @ rotation_matrix

               
                
                # 2. Convert world matrix to local matrix relative to the current parent
                if physics_object.parent:
                    if physics_object.parent_type == 'BONE' and physics_object.parent_bone in physics_object.parent.pose.bones:
                        parent_bone_pose = physics_object.parent.pose.bones[physics_object.parent_bone]
                        parent_world = physics_object.parent.matrix_world @ Matrix.Translation( 1 * (parent_bone_pose.tail - parent_bone_pose.head)) @ parent_bone_pose.matrix
                    else:
                        parent_world = physics_object.parent.matrix_world
                        
                    parent_space = parent_world @ physics_object.matrix_parent_inverse
                    local_matrix = parent_space.inverted() @ target_world_matrix
                else:
                    local_matrix = target_world_matrix
                
                loc, rot, _ = local_matrix.decompose()
                
                if frame in frames_loc:
                    for i in range(3):
                        kp = loc_curves[i].keyframe_points[idx_loc]
                        kp.co = (frame, loc[i])
                        kp.interpolation = interp
                    idx_loc += 1
                
                if frame in frames_rot:
                    if prev_euler:
                        rot_euler = rot.to_euler(physics_object.rotation_mode, prev_euler)
                    else:
                        rot_euler = rot.to_euler(physics_object.rotation_mode)
                    prev_euler = rot_euler
                    for i in range(3):
                        kp = rot_curves[i].keyframe_points[idx_rot]
                        kp.co = (frame, rot_euler[i])
                        kp.interpolation = interp
                    idx_rot += 1

            if frame in frames_scale:
                direct_scale = pose_bone.scale
                for i in range(3):
                    kp = scale_curves[i].keyframe_points[idx_scale]
                    kp.co = (frame, direct_scale[i])
                    kp.interpolation = interp
                idx_scale += 1
        
        for fc in loc_curves + rot_curves + scale_curves:
            fc.update()
        
        # --- 4. CLEANUP ---
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='POSE')
        
        for c, _ in constraints:
            if c: c.enabled = True
        
        bone.toggleConstraints = True
        
        return True, f"Transferred keys (Loc:{len(frames_loc)} Rot:{len(frames_rot)} Scale:{len(frames_scale)})"
    
    
    # -------------------------------------------------------------------------
    # Execution
    # -------------------------------------------------------------------------
    
    def transfer_keyframes(self, context):
        """Transfer bone animation to physics objects for all selected bones."""
        armature = context.active_object
        selected_bones = list(context.selected_pose_bones)
        
        if not selected_bones:
            self.report({'WARNING'}, "No pose bones selected")
            return {'CANCELLED'}
        
        # 1. Disable all physics modifiers on the simulated meshes before the transfer loop
        disabled_modifiers = []
        for bone in selected_bones:
            physics_object = getattr(bone, "bbdObject", None)
            if physics_object:
                for mod in physics_object.modifiers:
                    if mod.type in {'SOFT_BODY', 'CLOTH'} and mod.show_viewport:
                        mod.show_viewport = False
                        disabled_modifiers.append(mod)
        
        # 2. Perform the transfer operation for all bones
        success_count = 0
        for bone in selected_bones:
            success, message = self.transfer_bone_animation(context, bone, armature)
            if success:
                success_count += 1
                self.report({'INFO'}, f"{bone.name}: {message}")
            else:
                self.report({'INFO'}, f"Skipping {bone.name}: {message}")
                
        # 3. Re-enable all physics modifiers now that everything is done
        for mod in disabled_modifiers:
            mod.show_viewport = True
        
        invalidate_cache(self, context, armature)
        return success_count
    
    def execute(self, context):
        original_frame = context.scene.frame_current
        
        bpy.ops.screen.frame_jump(end=False)
        
        success_count = self.transfer_keyframes(context)
        
        context.scene.frame_set(original_frame)
        
        if success_count > 0:
            self.report({'INFO'}, f"Successfully transferred animation for {success_count} bone(s)")
            return {'FINISHED'}
        
        self.report({'WARNING'}, "No animations were transferred")
        return {'CANCELLED'}


class AddPhysics(bpy.types.Operator):
    """Make the bone dynamic"""
    bl_idname = "object.bdp_add_physics"
    bl_label = "Add Bone Dynamics"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.mode == 'POSE' and len(context.selected_pose_bones) > 0:
            return True
        else:
            return False
    
    def execute(self, context):
        ensure_collection_exists(context)
        main(self, context)
        return {'FINISHED'}


class RemovePhysics(bpy.types.Operator):
    """Restore the bone to its original state"""
    bl_idname = "object.bdp_remove_physics"
    bl_label = "Remove Bone Dynamics"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not any(collection.name == "BoneDynamics" for collection in bpy.data.collections):
            return False
        if context.mode == 'POSE':
            return True
        else:
            return False

    def execute(self, context):
        clearScene(self, context)
        return {'FINISHED'}


class SetDefault(bpy.types.Operator):
    """Set current parameters to default"""
    bl_idname = "object.bdp_set_default"
    bl_label = "Reset Parameters"

    @classmethod
    def poll(cls, context):
        if context.mode == 'POSE' and len(context.selected_pose_bones) > 0:
            return True
        else:
            return False

    def execute(self, context):
        setDefault(self, context)
        return {'FINISHED'}


class SelectBone(bpy.types.Operator):
    """Select current bone using Pose Bone data"""
    bl_idname = "pose.select_bone"
    bl_label = "Select this bone"
    bone_name: bpy.props.StringProperty(default="", options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        # Ensure we are in Pose Mode and have an armature
        return (context.active_object and 
                context.active_object.type == 'ARMATURE' and 
                context.mode == 'POSE')

    def execute(self, context):
        armature = context.active_object
        
        # Split the name as per your previous logic
        name_parts = self.bone_name.split('|')
        target_name = name_parts[0]

        # Access the bone via the Pose Bones collection
        pose_bones = armature.pose.bones
        
        if target_name in pose_bones:
            p_bone = pose_bones[target_name]
            
            # Selection state is accessed via the underlying 'bone' object
            # Setting this to True without calling a 'deselect_all' operator 
            # makes the selection incremental.
            p_bone.select = True
            
            # To make it the "Active" bone (the one colored yellow), 
            # we must set it in the armature data.
            # armature.data.bones.active = p_bone
            
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, f"Pose bone '{target_name}' not found.")
            return {'CANCELLED'}


def updateToggleConstraints(self, context):
    """Update constraint enabled state for a bone."""
    bone = self
    displace_constraint_name = "BoneDynamics-displace-" + self.name
    damped_constraint_name = "BoneDynamics-damped-" + self.name
    
    displace_constraint = bone.constraints.get(displace_constraint_name)
    damped_constraint = bone.constraints.get(damped_constraint_name)
    
    if displace_constraint:
        displace_constraint.enabled = self.toggleConstraints
    if damped_constraint:
        damped_constraint.enabled = self.toggleConstraints


def invalidate_cache(self, context, armature):
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    coll = bpy.data.collections.get('BoneDynamics')
    if coll:
        print("Collection found toggle edit mode")
        for obj in coll.all_objects:
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        bpy.context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='POSE')


class BDP_OT_ConfirmOverwritePreset(bpy.types.Operator):
    """Confirm Overwriting an Existing Preset"""
    bl_idname = "bonedynamics.confirm_overwrite_preset"
    bl_label = "Preset already exists. Overwrite?"
    bl_options = {'REGISTER', 'INTERNAL'}
    
    name: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Call the add operator but bypass the overwrite check
        bpy.ops.bonedynamics.object_display_preset_add(
            name=self.name, 
            confirm_overwrite=True
        )
        self.report({'INFO'}, f"Preset '{self.name}' overwritten successfully.")
        return {'FINISHED'}



class ExecutePresets(bpy.types.Operator):
    """Execute a preset"""
    bl_idname = "bonedynamics.execute_bdpresets"
    bl_label = "Execute a Python Preset"

    filepath: bpy.props.StringProperty(
        subtype='FILE_PATH',
        options={'SKIP_SAVE'},
    )
    menu_idname: bpy.props.StringProperty(
        name="Menu ID Name",
        description="ID name of the menu this was called from",
        options={'SKIP_SAVE'},
    )

    def execute(self, context):
        filepath = self.filepath
        preset_class = getattr(bpy.types, self.menu_idname)
        preset_class.bl_label = bpy.path.display_name(basename(filepath))

        ext = splitext(filepath)[1].lower()
        print('presets execution', filepath)
        
        if ext not in {".py", ".xml"}:
            self.report({'ERROR'}, "Unknown file type: %r" % ext)
            return {'CANCELLED'}

        if ext == ".py":
            try:
                print('exec preset ' + preset_class.bl_label)
                bpy.utils.execfile(filepath)
                bpy.utils.execfile(filepath)
                context.view_layer.update()
            except Exception as ex:
                self.report({'ERROR'}, "Failed to execute the preset: " + repr(ex))

        elif ext == ".xml":
            import rna_xml
            rna_xml.xml_file_run(context, filepath, preset_class.preset_xml_map)

        return {'FINISHED'}


class OBJECT_MT_display_presets(Menu):
    bl_label = "Presets"
    preset_subdir = "bonedynamics"
    preset_operator = "bonedynamics.execute_bdpresets"
    preset_operator_defaults = {
        "menu_idname": 'OBJECT_MT_display_presets'
    }
    draw = Menu.draw_preset
    
    @classmethod
    def poll(cls, context):
        return True


class AddPresetObjectDisplay(AddPresetBase, bpy.types.Operator):
    """Save current parameters as a preset"""
    bl_idname = "bonedynamics.object_display_preset_add"
    bl_label = "Save as a preset"
    preset_menu = "OBJECT_MT_display_presets"
    
    confirm_overwrite: bpy.props.BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    
    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and len(context.selected_pose_bones) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        # Force add mode
        self.remove_active = False 
        
        # Check if we haven't confirmed an overwrite yet
        if not self.confirm_overwrite:
            target_path = os.path.join("presets", self.preset_subdir)
            target_path = bpy.utils.user_resource('SCRIPTS', path=target_path, create=False)
            
            if target_path:
                name_clean = bpy.path.clean_name(self.name)
                preset_file = os.path.join(target_path, name_clean + ".py")
                
                # If the file exists, pause execution and call the confirmation dialog
                if os.path.exists(preset_file):
                    bpy.ops.bonedynamics.confirm_overwrite_preset('INVOKE_DEFAULT', name=self.name)
                    return {'FINISHED'}

        try:
            return super().execute(context)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save preset: {str(e)}")
            return {'CANCELLED'}
    
    preset_defines = [
        "obj = bpy.context.active_pose_bone",
        "objs = bpy.context.selected_pose_bones",
        "for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneElasticity = obj.boneElasticity;i.boneBend = obj.boneBend;i.boneGravity = obj.boneGravity;i.collisionDistance = obj.collisionDistance"
    ]
    preset_values = [
        "obj.boneMass", "obj.boneFriction", "obj.boneDamping", "obj.boneStrength",
        "obj.boneStiffness", "obj.boneBend", "obj.boneSpeed", "obj.boneElasticity",
        "obj.boneGravity", "obj.collisionDistance"
    ]
    preset_subdir = "bonedynamics"

class RemovePresetObjectDisplay(AddPresetBase, bpy.types.Operator):
    """Remove the active preset"""
    bl_idname = "bonedynamics.object_display_preset_remove"
    bl_label = "Delete Active Preset?"
    preset_menu = "OBJECT_MT_display_presets"

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and len(context.selected_pose_bones) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Force remove mode
        self.remove_active = True 
        try:
            return super().execute(context)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to remove preset: {str(e)}")
            return {'CANCELLED'}

    # AddPresetBase requires these to exist even when removing
    preset_defines = AddPresetObjectDisplay.preset_defines
    preset_values = AddPresetObjectDisplay.preset_values
    preset_subdir = "bonedynamics"

class BONES_PT_Panel(Panel):
    bl_label = "Dynamic Bones"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Bone Dynamics Pro'
    bl_parent_id = "BBD_PT_PANEL"
    bl_options = {"HEADER_LAYOUT_EXPAND"}

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.operator('object.sync_timerange', text="Sync Time Range")
        
        for obj in bpy.data.objects:
            try:
                obj['dynamics']
                if obj['arma'] == context.active_object.id_data:
                    row = layout.row(align=True)
                    row.label(text=obj.name, icon="BONE_DATA")
                    armature = obj['arma']
                    bone = armature.pose.bones.get(obj['bone'])
                    
                    if context.mode == 'POSE':
                        row.operator('pose.select_bone', text="", icon='RESTRICT_SELECT_OFF').bone_name = obj.name
                        row.prop(
                            bone,
                            "toggleConstraints",
                            text="",
                            icon='HIDE_ON' if not bone.toggleConstraints else 'HIDE_OFF',
                            toggle=False
                        )
                    
                    for mod in obj.modifiers:
                        if mod.type == "SOFT_BODY" or mod.type == "CLOTH":
                            row.prop(mod, 'show_viewport', text="")
            except:
                continue


class BBD_PT_Panel(Panel):
    bl_label = "Bone Dynamics Pro"
    bl_idname = "BBD_PT_PANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BDP 2.0'

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        if context.mode == 'POSE':
            presets_box = layout.box()
            presets_box.label(text="Presets", icon='PRESET')
            row = presets_box.row(align=True)
            row.menu(OBJECT_MT_display_presets.__name__, text=OBJECT_MT_display_presets.bl_label)
            row.operator(AddPresetObjectDisplay.bl_idname, text="", icon='ADD')
            row.operator(RemovePresetObjectDisplay.bl_idname, text="", icon='REMOVE')
            row.operator('bonedynamics.location_presetperso', text="", icon='FILE_FOLDER')
            copy_paste_row = presets_box.row(align=True)
            copy_paste_row.operator("pose.bdp_copy_properties", text="Copy Values", icon='COPYDOWN')
            copy_paste_row.operator("pose.bdp_paste_properties", text="Paste Values", icon='PASTEDOWN')

        # === Main Control Section ===
        main_box = layout.box()
        main_box.label(text="Core Controls", icon='PHYSICS')
        
        col = main_box.column(align=True)
        col.operator('object.bdp_add_physics', icon='BONE_DATA', text="Add Dynamics")
        col.operator('object.bdp_remove_physics', icon='X', text="Remove Dynamics")
        col.operator('object.bdp_set_default', icon='LOOP_BACK', text="Reset All")
        col.operator('wm.bdp_bake_animation', icon='RENDER_ANIMATION', text="Bake Animation")
        
        # === Transfer Section ===
        transfer_box = layout.box()
        transfer_box.label(text="Transfer Animation", icon='ANIM_DATA')
        row = transfer_box.row(align=True)
        row.operator('object.bdp_transfer_animation', icon='ARMATURE_DATA', text="Transfer")
        row.prop(context.scene, "bdp_auto_transfer", text="", icon='CHECKBOX_HLT' if context.scene.bdp_auto_transfer else 'CHECKBOX_DEHLT')
        
        # === Settings Section ===
        settings_box = layout.box()
        settings_box.label(text="Settings", icon='TOOL_SETTINGS')
        
        col = settings_box.column(align=True)
        col.prop(context.scene, "boneStretch", toggle=True)
        col.prop(context.scene, "chainMode", toggle=True)
        col.prop(context.scene, "dynamicParent", toggle=True)
        col.operator('object.bdp_add_control_point', icon='HOOK', text="Add Hook")
        # if context.scene.chainMode:
        #     col.prop(context.scene, "PinFirst", toggle=True)
        
        
        # === Bone Presets (Only in Pose Mode) ===
       
        
        # === Active Bone Properties ===
        if context.mode == 'POSE' and context.active_object.type == "ARMATURE" and context.active_pose_bone:

            bone = context.active_pose_bone
            dynamic = getattr(bone, 'dynamics', False)
            chain = getattr(bone, 'chain', False)
            chainParent = getattr(bone, 'chainParent', False)
            displace = getattr(bone, "displace", False)
            bone_box = layout.box()
            header = bone_box.row()
            if chain:
                header.operator('bonedynamics.select_main_bone', icon='CONSTRAINT_BONE', text="Select the main chain bone") 

                if chainParent != 'None' and chainParent == bone.name:
                    bone_box.label(text="• Chain Parent (Keyframe here)", icon='CONSTRAINT_BONE')
            bone_box.label(text=f"Active Bone: {bone.name}", icon='BONE_DATA')
            
            if dynamic:
                bone_box.label(text="• Dynamic Bone", icon='PHYSICS')
            
             
            
            # if chainParent != 'None' and chainParent == bone.name:
            #     bone_box.label(text="• Chain Parent (Keyframe here)", icon='CONSTRAINT_BONE')
                
            
            
            row = bone_box.row()
            row.prop(bone, "displace", toggle=True)
            if displace:
                row.prop(bone, "headDisplace",  slider = True)
            # Properties in two columns for better density
            flow = bone_box.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
            
            
            flow.prop(bone, "toggleDynamics",  slider = True)
            flow.prop(bone, "boneMass", text="Mass" , slider = True)
            flow.prop(bone, "boneFriction", text="Friction" , slider = True)
            flow.prop(bone, "boneDamping", text="Damping" , slider = True)
            flow.prop(bone, "boneStiffness", text="Stiffness" , slider = True)
            flow.prop(bone, "boneSpeed", text="Speed" , slider = True)
            flow.prop(bone, "boneBend", text="Bend" , slider = True)
            flow.prop(bone, "boneElasticity", text="Elasticity" , slider = True)
            flow.prop(bone, "boneGravity", text="Gravity" , slider = True)
            flow.prop(bone, "collisionDistance", text="Collision Dist" , slider = True)
           
            
      


class WM_OT_bakeBone(bpy.types.Operator):
    """Bake the physics of the selected bones into keyframes (Playback sync needs to be in 'Play Every Frame')"""
    bl_idname = "wm.bdp_bake_animation"
    bl_label = "Bake the animation of the selected bones"
    
    clearConstraint: bpy.props.BoolProperty(default=True)
    bakeNewStrip: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        if context.mode == 'POSE' and len(context.selected_pose_bones) > 0 and context.active_object.type == "ARMATURE":
            return True
        else:
            return False

    def execute(self, context):
        armature = context.active_object
        start = context.scene.frame_start
        bpy.context.scene.sync_mode = 'NONE'
        
        for num, bone in enumerate(context.selected_pose_bones):
            dynamics = getattr(bone, "dynamics", False)
            
            if dynamics == True :

                bone_dynamics_obj = getattr(bone, "bbdObject", None)
                if bone_dynamics_obj:
                    bone.bone.inherit_scale = 'ALIGNED'
                    continue
                
            else:
                edit_bone = armature.data.bones[bone.name]
                edit_bone.select = False
                print('deselcting non dynamics bones' , bone)
                if bpy.app.version >= (4, 6, 0):
                    bone.select = False
                else:
                    bone.bone.select = False
               
        end = context.scene.frame_end
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        
        step_decimal = context.scene.bakeStep / 100
        bpy.ops.object.mode_set(mode='POSE')
        
        if bpy.app.version >= (4, 2, 0):
            bpy.ops.nla.bake(
                frame_start=start,
                frame_end=end,
                step=1,
                use_current_action=self.bakeNewStrip,
                only_selected=True,
                visual_keying=True,
                clean_curves=True,
                bake_types={'POSE'},
                channel_types={'LOCATION', 'ROTATION', 'SCALE'}
            )
        else:
            bpy.ops.nla.bake(
                frame_start=start,
                frame_end=end,
                step=1,
                use_current_action=self.bakeNewStrip,
                only_selected=True,
                visual_keying=True,
                clean_curves=True,
                bake_types={'POSE'}
            )
        
        area = context.area
        old_type = area.type
        area.type = 'GRAPH_EDITOR'
        bpy.ops.graph.clean(channels=True)
        bpy.ops.graph.decimate(mode='RATIO', factor=context.scene.bakeStep)
        bpy.ops.graph.select_all( "INVOKE_DEFAULT",action="DESELECT")
        area.type = old_type
        
        
        if self.clearConstraint:
            clearScene(self, context)

        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def draw(self, context):
        row = self.layout
        row.label(text='IMPORTANT:', translate=True, icon='NONE', icon_value=0)
        row.label(text='The baking range will follow the timeline length.', translate=True, icon='NONE', icon_value=0)
        row.label(text='You need to play fully the animation at least once', translate=True, icon='NONE', icon_value=0)
        row.label(text='Make sure that your playback sync is set to play every frame', translate=True, icon='NONE', icon_value=0)
        row.prop(self, "clearConstraint", text="Clear constraints and physics object")
        row.prop(self, "bakeNewStrip", text="Bake this animation into the same NLA strip")

        row.prop(context.scene, "bakeStep", text="Simplification factor", slider=True)


class OpenFileBrowser(bpy.types.Operator):
    """Open location"""
    bl_idname = "bonedynamics.location_presetperso"
    bl_label = "Open location of Presets"

    def execute(self, context):
        bpy.ops.wm.path_open(filepath=os.path.join(bpy.utils.script_path_user(), 'presets', 'bonedynamics'))
        return {'FINISHED'}


class SelectMainBone(bpy.types.Operator):
    """Select the main bone of the chain, you need to select this bone if you want to keyframe values for a chain of bones"""
    bl_idname = "bonedynamics.select_main_bone"
    bl_label = "Open location of Presets"

    def execute(self, context):
        print('select the bone of the chain')
        armature = context.active_object
        
        if armature:
            chainParent = getattr(context.active_pose_bone, "chainParent", None)
            if chainParent:
                bone = armature.pose.bones.get(chainParent)
                bpy.ops.pose.select_all(action='DESELECT')
                if bpy.app.version >= (4, 6, 0):
                        bone.select = True
                        context.object.data.bones.active = bone.bone
                else:   
                        context.object.data.bones.active = bone.bone
                        bone.bone.select = True
            else:            
                pose_bones = armature.pose.bones
                for bone in pose_bones:
                    chainParent = getattr(bone, "chainParent", None)
                    if chainParent == bone.name:
                        bpy.ops.pose.select_all(action='DESELECT')
                        if bpy.app.version >= (4, 6, 0):
                            context.object.data.bones.active = bone.bone
                            bone.select = True
                        else:
                            context.object.data.bones.active = bone.bone
                            bone.bone.select = True
        return {'FINISHED'}

class BdModalOperator(bpy.types.Operator):
    """Modal operator for handling bone transformations"""
    bl_idname = "object.bd_modal_operator"
    bl_label = "Bone Dynamics Modal Operator"


    @classmethod
    def poll(cls, context):
        if bpy.context.object.mode == 'POSE'  and  context.active_pose_bone:
            chain = getattr(context.active_pose_bone, "chain", False)
            if chain:
                return False
            return True
        else:
            return False

    def execute(self, context):
        """Invalidate the physics cache."""
        print('modal active')
        return {'FINISHED'}

    def snap_and_disable(self, context):
        """
        Captures the visual position of the bone (influenced by physics),
        applies it to the bone's actual transform, and then disables constraints.
        This prevents the 'jump'.
        """
        # 1. Ensure the scene is up to date to get the correct visual matrix
        setattr(self.bone, "boneStiffness", 50.0)
        context.view_layer.update()
        
        # 2. Capture the visual matrix (World Space representation of the bone with constraints)
        visual_matrix = self.bone.matrix.copy()
        
        # 3. Logic to determine if we should disable constraints (copied from your original logic)
        chain = getattr(self.bone, "chain", False)
        should_disable_damped = not chain and self.constraint_damped
        should_disable_displace = False
        
        displace = getattr(self.bone, "displace", None)
        if displace and not chain and self.constraint_displace:
            should_disable_displace = True

        print('should_disable_damped', should_disable_damped)
        print('should_disable_displace', should_disable_displace)
        
        # Only proceed with the snap if we are actually going to disable something
        if should_disable_damped or should_disable_displace:
            
            # 4. Disable the constraints
            if should_disable_damped:
                self.constraint_damped.enabled = False
            if should_disable_displace:
                self.constraint_displace.enabled = False
            
            # 5. Force update so Blender knows constraints are now OFF
            # This is crucial so the next line writes to the underlying Transform, not against the Constraint
            context.view_layer.update()
            
            # 6. Apply the visual matrix we captured earlier
            # Blender will automatically calculate the necessary local location/rotation/scale
            # to match this matrix in world space.
            self.bone.matrix = visual_matrix
            
            # 7. Final update so the Transform Operator (invoked next) sees the new position
            context.view_layer.update()

    def modal(self, context, event):
        
        if not self.bbd:
            bpy.ops.transform.rotate('INVOKE_DEFAULT')
            return {'CANCELLED'}

        if event.type == 'R' and event.shift:  # Rotation
            # Fix: Snap and disable constraints BEFORE invoking the transform
            print( 'rotating modal enabled')
            self.snap_and_disable(context)
            
            bpy.ops.transform.rotate('INVOKE_DEFAULT')
            return {'PASS_THROUGH'}
        
        if event.type == 'T':  # Translation
            # Fix: Snap and disable constraints BEFORE invoking the transform
            self.snap_and_disable(context)
            
            bpy.ops.transform.translate('INVOKE_DEFAULT')
            return {'PASS_THROUGH'}
        
        if event.type == 'LEFTMOUSE':  # Confirm
            if self.bone:
                physics_object = getattr(self.bone, "bbdObject", None)
               
                if physics_object:
                    armature = self.bone.id_data
                   
                    # 1. Get the precise World Matrix of the Bone
                    bone_world_matrix = armature.matrix_world @ self.bone.matrix
                    
                    # 2. Define the Rotation Offset (-90 degrees on X)
                    rotation_matrix = Matrix.Rotation(math.radians(-90.0), 4, 'X')
                    
                    # 3. Apply the Transform to the Physics Object
                    physics_object.matrix_world = bone_world_matrix @ rotation_matrix
                    physics_object.scale = Vector((1,1,1))
                    
                    # Re-enable constraints
                    if self.constraint_damped:
                        self.constraint_damped.enabled = True
                    if self.constraint_displace:
                        self.constraint_displace.enabled = True
                    
                    if context.scene.tool_settings.use_keyframe_insert_auto:
                        physics_object.keyframe_insert("rotation_euler")
                        physics_object.keyframe_insert(data_path="location")
                    
                    ### Free the Cache
                    invalidate_cache(self, context, armature)
                    setattr(self.bone, "boneStiffness", self.oldStiffness)
                    
                   
            return {'FINISHED'}
        
        elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel
            # Re-enable constraints if canceled
            if self.constraint_damped:
                self.constraint_damped.enabled = True
            if self.constraint_displace:
                self.constraint_displace.enabled = True
            setattr(self.bone, "boneStiffness", self.oldStiffness)
            return {'CANCELLED'}
        
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.bone = context.active_pose_bone
        self.constraint_damped = None
        self.constraint_displace = None
        self.bbd = getattr(self.bone, "bbdObject", None)
        self.oldStiffness=  getattr(self.bone, "boneStiffness", 0.0)
        if self.bone and self.bbd:
            constraint_name = 'BoneDynamics-damped-' + self.bone.name
            displace_constraint_name = 'BoneDynamics-displace-' + self.bone.name
            self.constraint_damped = self.bone.constraints.get(constraint_name)
            self.constraint_displace = self.bone.constraints.get(displace_constraint_name)
            self.execute(context)
        
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

addon_keymaps = []


def register():
    """Register all classes and properties."""
    bpy.utils.register_class(BBD_PT_Panel)
    bpy.utils.register_class(BONES_PT_Panel)
    bpy.utils.register_class(AddPhysics)
    bpy.utils.register_class(SetDefault)
    bpy.utils.register_class(ExecutePresets)
    bpy.utils.register_class(OBJECT_MT_display_presets)
    bpy.utils.register_class(AddPresetObjectDisplay)
    bpy.utils.register_class(WM_OT_bakeBone)
    bpy.utils.register_class(SelectBone)
    bpy.utils.register_class(SyncTimeRange)
    bpy.utils.register_class(TransferAnimation)
    bpy.utils.register_class(RemovePhysics)
    bpy.utils.register_class(BdModalOperator)
    bpy.utils.register_class(OpenFileBrowser)
    bpy.utils.register_class(VIEW3D_OT_helper_tips)
    bpy.utils.register_class(AddControlPoint)
    bpy.utils.register_class(BDP_OT_ConfirmOverwritePreset)
    bpy.utils.register_class(RemovePresetObjectDisplay)
    bpy.utils.register_class(BDP_OT_CopyProperties)
    bpy.utils.register_class(BDP_OT_PasteProperties)
    bpy.utils.register_class(SelectMainBone)
   

    # Scene properties

    bpy.types.WindowManager.show_helper_tips = bpy.props.BoolProperty(
        name="Show Helper Tips",
        default=False,
        update=update_tips_toggle
    )
    
    bpy.types.WindowManager.helper_tips_duration = bpy.props.FloatProperty(
        name="Tip Duration",
        default=6.0,
        min=1.0
    )
    
    bpy.types.WindowManager.helper_tips_fade = bpy.props.FloatProperty(
        name="Fade Duration",
        default=0.8,
        min=0.1,
        max=5.0
    )

    bpy.types.Scene.bdp_auto_transfer = bpy.props.BoolProperty(
        name="Auto Transfer Keyframes to physics objects",
        description="Only for connected bones",
        default=False
    )


    bpy.types.Scene.chainMode = bpy.props.BoolProperty(
        name="Chain mode",
        description="Only for connected bones",
        default=False,
        update=updateChain
    )
    # bpy.types.Scene.clothMode = bpy.props.BoolProperty(
    #     name="Cloth mode",
    #     description="Only for connected bones, This mode is useful for hair or clothes",
    #     default=False,
    #     update=updateCloth
    # )
    bpy.types.Scene.boneStretch = bpy.props.BoolProperty(
        name="Allow Stretching",
        description="Allow the bones to stretch",
        default=False
    )
    bpy.types.Scene.bakeStrip = bpy.props.BoolProperty(
        name="Bake strip",
        description="Allow baking into strips",
        default=False
    )

    bpy.types.Scene.PinFirst = bpy.props.BoolProperty(
        name="Pin first Bone",
        description="Pin the first bone of the chain",
        default=True
    )
    bpy.types.Scene.bonedynamicsDebug = bpy.props.BoolProperty(
        name="Debug",
        description="Debug mode",
        default=False
    )
    bpy.types.Scene.dynamicParent = bpy.props.BoolProperty(
        name="Dynamic Parent",
        description="Enable this if you want to assign a custom parent which will be the active bone",
        default=False
    )
    bpy.types.Scene.bakeStep = bpy.props.FloatProperty(
        name="Curve simplification",
        description="Higher number means lower keyframes and less accuracy too.",
        default=0.5,
        min=0,
        max=1
    )
    bpy.types.Scene.boneLength = bpy.props.FloatProperty(
        name="Bone Length",
        description="If the chain is not working properly, try changing this parameter",
        default=100,
        min=10,
        max=1000,
        step=100,
        options={'LIBRARY_EDITABLE'},
        override={'LIBRARY_OVERRIDABLE'}
    )
    
    # Pose bone properties
    bpy.types.PoseBone.bbdObject = bpy.props.PointerProperty(
        name="BBD pointer",
        type=bpy.types.Object,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )


    bpy.types.PoseBone.dynamics = bpy.props.BoolProperty(
        name="dynamics",
        default=False,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )

    bpy.types.PoseBone.chainParent = bpy.props.StringProperty(
        name="chainParent",
        default="None",
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )

    bpy.types.PoseBone.chain = bpy.props.BoolProperty(
        name="chain",
        default=False,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )


    bpy.types.PoseBone.toggleConstraints = bpy.props.BoolProperty(
        name="Toggle constraints",
        default=True,
        update=updateToggleConstraints,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.displace = bpy.props.BoolProperty(
        name="Displacement",
        description="Allow the bone to translate on top of rotating, this is useful for IK bones",
        default=False,
        update=updateDisplace,
        options={'LIBRARY_EDITABLE'},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.dynamics = bpy.props.BoolProperty(
        name="Dynamics",
        description="Dynamics",
        default=False,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.displaceOrg = bpy.props.BoolProperty(
        name="Displacement original",
        description="Original bone connect",
        default=False,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneMass = bpy.props.FloatProperty(
        name="Mass",
        description="Mass of the bone",
        default=0.1,
        min=0,
        max=50,
        step=0.1,
        update=updateMass,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )

    bpy.types.PoseBone.headDisplace = bpy.props.FloatProperty(
        name="Displacement",
        description="Bone Displacement pivot point",
        default=0.5,
        min=0,
        max=1,
        update=updateDisplaceValue,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneFriction = bpy.props.FloatProperty(
        name="Air Friction",
        description="Air Friction",
        default=4,
        min=0,
        max=10,
        update=updateFriction,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneStiffness = bpy.props.FloatProperty(
        name="Stiffness",
        description="Stiffness of the bone",
        default=5.0,
        min=0,
        max=40,
        update=updateStiffness,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneDamping = bpy.props.FloatProperty(
        name="Damping",
        description="Damping of the bone",
        default=10,
        min=0,
        max=50,
        update=updateDamping,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneStrength = bpy.props.FloatProperty(
        name="Strength",
        description="Strength of the bone",
        default=0.7,
        min=0,
        max=1,
        update=updateStrength,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneSpeed = bpy.props.FloatProperty(
        name="Speed",
        description="Speed multiplier",
        default=1,
        min=0,
        max=100,
        update=updateSpeed,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.toggleDynamics = bpy.props.FloatProperty(
        name="Influence",
        description="Constraint influence",
        default=1,
        min=0,
        max=1,
        update=updateToggle,
        options={'LIBRARY_EDITABLE' , "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneElasticity = bpy.props.FloatProperty(
        name="Elasticity",
        description="Bone elasticity",
        default=0.0,
        min=-1.0,
        max=1.0,
        update=updateElasticity,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneBend = bpy.props.FloatProperty(
        name="Bending",
        description="Bone bending resistance",
        default=10,
        min=0,
        max=100,  
        step=1,
        update=updateBend,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.boneGravity = bpy.props.FloatProperty(
        name="Gravity",
        description="Gravity multiplier",
        default=1.0,
        min=-10,
        max=10,
        update=updateGravity,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    bpy.types.PoseBone.collisionDistance = bpy.props.FloatProperty(
        name="Collision Distance",
        description="Collision Radius",
        default=0.015,
        min=0.001,
        max=1,
        update=updateRadius,
        options={'LIBRARY_EDITABLE', "ANIMATABLE"},
        override={'LIBRARY_OVERRIDABLE'}
    )
    
    check_presets()

    wm = bpy.context.window_manager
    
    kc = wm.keyconfigs.addon
   
    
    if kc:
        
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D' )
        kmi = km.keymap_items.new(BdModalOperator.bl_idname, type='R', value='PRESS' , shift=True)
        kmg = km.keymap_items.new(BdModalOperator.bl_idname, type='T', value='PRESS' , shift=True)
        addon_keymaps.append((km, kmi))
        addon_keymaps.append((km, kmg))


def unregister():
    """Unregister all classes and properties."""
    bpy.utils.unregister_class(BBD_PT_Panel)
    bpy.utils.unregister_class(BONES_PT_Panel)
    bpy.utils.unregister_class(AddPhysics)
    bpy.utils.unregister_class(RemovePhysics)
    bpy.utils.unregister_class(SetDefault)
    bpy.utils.unregister_class(OBJECT_MT_display_presets)
    bpy.utils.unregister_class(AddPresetObjectDisplay)
    bpy.utils.unregister_class(ExecutePresets)
    bpy.utils.unregister_class(WM_OT_bakeBone)
    bpy.utils.unregister_class(SelectBone)
    bpy.utils.unregister_class(SyncTimeRange)
    bpy.utils.unregister_class(TransferAnimation)
    bpy.utils.unregister_class(BdModalOperator)
    bpy.utils.unregister_class(OpenFileBrowser)
    bpy.utils.unregister_class(VIEW3D_OT_helper_tips)
    bpy.utils.unregister_class(AddControlPoint)
    bpy.utils.unregister_class(BDP_OT_ConfirmOverwritePreset)
    bpy.utils.unregister_class(RemovePresetObjectDisplay)
    bpy.utils.unregister_class(BDP_OT_CopyProperties)
    bpy.utils.unregister_class(BDP_OT_PasteProperties)
    bpy.utils.unregister_class(SelectMainBone)
    del bpy.types.WindowManager.show_helper_tips
    del bpy.types.WindowManager.helper_tips_duration
    del bpy.types.WindowManager.helper_tips_fade
    

    # Remove hotkeys
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    # Remove properties
    del bpy.types.Scene.boneStretch
    del bpy.types.Scene.chainMode
    del bpy.types.Scene.bakeStep
    del bpy.types.Scene.PinFirst
    # del bpy.types.Scene.clothMode
    del bpy.types.Scene.boneLength
    del bpy.types.Scene.dynamicParent


if __name__ == "__main__":
    register()