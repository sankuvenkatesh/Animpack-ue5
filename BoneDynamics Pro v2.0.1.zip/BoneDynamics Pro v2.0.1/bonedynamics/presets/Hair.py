import bpy
obj = bpy.context.active_pose_bone


if bpy.context.scene.chainMode:


	obj.boneMass = 0.3
	obj.boneFriction = 2.0
	obj.boneStiffness = 0.0
	obj.boneDamping = 30
	obj.boneBend = 0  
	obj.boneSpeed = 2.5  
	obj.boneStrength = 0.5
	obj.boneElasticity = 0.00
	obj.collisionDistance = 0.01
	obj.boneGravity = 1.0



else:
	obj.boneMass = 0.30
	obj.boneFriction = 2.0
	obj.boneDamping = 40.0
	obj.boneStrength = 0.699999988079071
	obj.boneStiffness = 0.0
	obj.boneSpeed = 2
	obj.boneBend = 0
	obj.boneElasticity = 0.5
	obj.collisionDistance = 0.01
	obj.boneGravity = 1.0


objs = bpy.context.selected_pose_bones
for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneBend = obj.boneBend;i.boneElasticity = obj.boneElasticity; i.boneGravity = obj.boneGravity; i.collisionDistance = obj.collisionDistance




