import bpy
obj = bpy.context.active_pose_bone


if bpy.context.scene.chainMode:


        obj.boneMass = 0.1
        obj.boneFriction = 4.0
        obj.boneStiffness = 5.0
        obj.boneDamping = 10
        obj.boneBend = 10  
        obj.boneSpeed = 1  
        obj.boneStrength = 0.5
        obj.boneElasticity = 0.03
        obj.collisionDistance = 0.01
        obj.boneGravity = 1.0



else:
        obj.boneMass = 0.1
        obj.boneFriction = 4.0
        obj.boneStiffness = 5.0
        obj.boneDamping = 10
        obj.boneBend = 10  
        obj.boneSpeed = 1  
        obj.boneStrength = 0.5
        obj.boneElasticity = 0.03
        obj.collisionDistance = 0.01
        obj.boneGravity = 1.0


objs = bpy.context.selected_pose_bones
for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneBend = obj.boneBend;i.boneElasticity = obj.boneElasticity; i.boneGravity = obj.boneGravity; i.collisionDistance = obj.collisionDistance



