import bpy
obj = bpy.context.active_pose_bone


if bpy.context.scene.chainMode:


	obj.boneMass = 0.35
	obj.boneFriction = 0.6
	obj.boneDamping = 0.9
	obj.boneStrength = 0.0
	obj.boneStiffness = 0.0
	obj.boneSpeed = 1
	obj.boneBend = 0.1
	obj.boneElasticity = 0.03



else:
	obj.boneMass = 0.30000001192092896
	obj.boneFriction = 12.0
	obj.boneDamping = 10.0
	obj.boneStrength = 0.699999988079071
	obj.boneStiffness = 0.18
	obj.boneSpeed = 1
	obj.boneBend = 10
	obj.boneElasticity = 0.5


objs = bpy.context.selected_pose_bones
for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneBend = obj.boneBend;i.boneElasticity = obj.boneElasticity



