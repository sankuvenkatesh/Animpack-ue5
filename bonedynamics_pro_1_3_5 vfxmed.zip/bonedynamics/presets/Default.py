import bpy
obj = bpy.context.active_pose_bone


if bpy.context.scene.chainMode:


        obj.boneMass = 0.5
        obj.boneFriction = 5
        obj.boneStiffness = 0.5
        obj.boneDamping = 5
        obj.boneBend = 10  
        obj.boneSpeed = 1  
        obj.boneStrength = 0.5
        obj.boneElasticity = 0.03



else:
	obj.boneMass = 0.30000001192092896
	obj.boneFriction = 12.0
	obj.boneDamping = 10.0
	obj.boneStrength = 0.699999988079071
	obj.boneStiffness = 0.8999999761581421
	obj.boneSpeed = 1
	obj.boneBend = 10
	obj.boneElasticity = 0.03


objs = bpy.context.selected_pose_bones
for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneBend = obj.boneBend;i.boneElasticity = obj.boneElasticity



