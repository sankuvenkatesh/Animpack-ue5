import bpy
obj = bpy.context.active_pose_bone


if bpy.context.scene.chainMode:


	obj.boneMass = 0.39
	obj.boneFriction = 1
	obj.boneDamping = 1
	obj.boneStrength = 0.88
	obj.boneStiffness = 0.93
	obj.boneSpeed = 1
	obj.boneBend = 10
	obj.boneElasticity = 0.00



else:
	obj.boneMass = 0.09
	obj.boneFriction = 6
	obj.boneDamping = 6
	obj.boneStrength = 0.8
	obj.boneStiffness = 0.5
	obj.boneSpeed = 1
	obj.boneBend = 10
	obj.boneElasticity = 0.03


objs = bpy.context.selected_pose_bones
for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneBend = obj.boneBend;i.boneElasticity = obj.boneElasticity



