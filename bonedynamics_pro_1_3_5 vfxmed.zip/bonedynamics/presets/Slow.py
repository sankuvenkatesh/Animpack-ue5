import bpy
obj = bpy.context.active_pose_bone


if bpy.context.scene.chainMode:


	obj.boneMass = 0.60
	obj.boneFriction = 15
	obj.boneDamping = 8
	obj.boneStrength = 0.18
	obj.boneStiffness = 0.0
	obj.boneSpeed = 1
	obj.boneBend = 10
	obj.boneElasticity = 0.03



else:
	obj.boneMass = 0.24
	obj.boneFriction =16
	obj.boneDamping = 12
	obj.boneStrength = 0.699999988079071
	obj.boneStiffness = 0.18
	obj.boneSpeed = 1
	obj.boneBend = 10
	obj.boneElasticity = 0.5


objs = bpy.context.selected_pose_bones
for i in objs:i.boneMass = obj.boneMass;i.boneFriction = obj.boneFriction;i.boneDamping = obj.boneDamping;i.boneStrength = obj.boneStrength;i.boneStiffness = obj.boneStiffness;i.boneSpeed = obj.boneSpeed;i.boneBend = obj.boneBend;i.boneElasticity = obj.boneElasticity



